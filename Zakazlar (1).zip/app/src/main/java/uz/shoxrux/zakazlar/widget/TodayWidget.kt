package uz.shoxrux.zakazlar.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.view.View
import android.widget.RemoteViews
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import uz.shoxrux.zakazlar.MainActivity
import uz.shoxrux.zakazlar.R
import uz.shoxrux.zakazlar.data.AppDatabase
import uz.shoxrux.zakazlar.data.Order
import uz.shoxrux.zakazlar.notify.Reminders
import uz.shoxrux.zakazlar.util.Dates

class TodayWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                render(context, appWidgetManager, appWidgetIds)
            } finally {
                pending.finish()
            }
        }
    }

    override fun onAppWidgetOptionsChanged(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int,
        newOptions: android.os.Bundle?
    ) {
        refresh(context)
    }

    companion object {
        const val ACTION_DONE = "uz.shoxrux.zakazlar.WIDGET_DONE"
        private const val MAX_ROWS = 10

        private val ROWS = intArrayOf(
            R.id.row0, R.id.row1, R.id.row2, R.id.row3, R.id.row4,
            R.id.row5, R.id.row6, R.id.row7, R.id.row8, R.id.row9
        )
        private val CHKS = intArrayOf(
            R.id.chk0, R.id.chk1, R.id.chk2, R.id.chk3, R.id.chk4,
            R.id.chk5, R.id.chk6, R.id.chk7, R.id.chk8, R.id.chk9
        )
        private val NAMES = intArrayOf(
            R.id.name0, R.id.name1, R.id.name2, R.id.name3, R.id.name4,
            R.id.name5, R.id.name6, R.id.name7, R.id.name8, R.id.name9
        )
        private val SUBS = intArrayOf(
            R.id.sub0, R.id.sub1, R.id.sub2, R.id.sub3, R.id.sub4,
            R.id.sub5, R.id.sub6, R.id.sub7, R.id.sub8, R.id.sub9
        )

        suspend fun render(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
            val today = Dates.today()
            val items = AppDatabase.get(ctx).orderDao().widgetList(today)
            for (id in ids) mgr.updateAppWidget(id, build(ctx, items, today))
        }

        fun refresh(ctx: Context) {
            val app = ctx.applicationContext
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val mgr = AppWidgetManager.getInstance(app)
                    val ids = mgr.getAppWidgetIds(ComponentName(app, TodayWidget::class.java))
                    if (ids.isNotEmpty()) render(app, mgr, ids)
                } catch (e: Exception) {
                    // vidjet yangilanmasa ilova ishiga xalaqit bermasin
                }
            }
        }

        private fun openApp(ctx: Context): PendingIntent =
            PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )

        private fun quickAdd(ctx: Context): PendingIntent =
            PendingIntent.getActivity(
                ctx, 1, Intent(ctx, QuickAddActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )

        private fun donePi(ctx: Context, id: Long): PendingIntent {
            val i = Intent(ctx, WidgetActionReceiver::class.java)
            i.action = ACTION_DONE
            i.data = Uri.parse("zakaz://done/$id")
            i.putExtra("id", id)
            return PendingIntent.getBroadcast(
                ctx, 0, i,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        }

        private fun build(ctx: Context, items: List<Order>, today: Long): RemoteViews {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_today)
            val count = items.size
            val title = "Bugun · " + Dates.short(today) + if (count > 0) "  ($count)" else ""
            rv.setTextViewText(R.id.widget_title, title)
            rv.setOnClickPendingIntent(R.id.widget_title, openApp(ctx))
            rv.setOnClickPendingIntent(R.id.widget_add, quickAdd(ctx))

            for (i in 0 until MAX_ROWS) {
                val o = items.getOrNull(i)
                if (o == null) {
                    rv.setViewVisibility(ROWS[i], View.GONE)
                } else {
                    val late = o.dateEpochDay < today
                    val time = o.timeMinutes?.let { Dates.clock(it) + "  " } ?: ""
                    rv.setViewVisibility(ROWS[i], View.VISIBLE)
                    rv.setTextViewText(NAMES[i], time + o.customer)
                    rv.setTextColor(NAMES[i], if (late) Color.parseColor("#FF8A8A") else Color.WHITE)
                    val sub = buildString {
                        if (late) append((today - o.dateEpochDay).toString() + " kun o'tgan")
                        val firstLine = o.details.lineSequence().firstOrNull { it.isNotBlank() }
                        if (firstLine != null) {
                            if (isNotEmpty()) append(" · ")
                            append(firstLine.trim())
                        }
                    }
                    if (sub.isEmpty()) {
                        rv.setViewVisibility(SUBS[i], View.GONE)
                    } else {
                        rv.setViewVisibility(SUBS[i], View.VISIBLE)
                        rv.setTextViewText(SUBS[i], sub)
                    }
                    rv.setOnClickPendingIntent(CHKS[i], donePi(ctx, o.id))
                    rv.setOnClickPendingIntent(ROWS[i], openApp(ctx))
                }
            }

            if (count > MAX_ROWS) {
                rv.setViewVisibility(R.id.widget_more, View.VISIBLE)
                rv.setTextViewText(R.id.widget_more, "+" + (count - MAX_ROWS) + " ta yana, ilovada ko'ring")
                rv.setOnClickPendingIntent(R.id.widget_more, openApp(ctx))
            } else {
                rv.setViewVisibility(R.id.widget_more, View.GONE)
            }
            rv.setViewVisibility(R.id.widget_empty, if (count == 0) View.VISIBLE else View.GONE)
            return rv
        }
    }
}

/** Vidjetdagi ○ tugmasi bosilganda zakazni "berilgan" qiladi. */
class WidgetActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != TodayWidget.ACTION_DONE) return
        val id = intent.getLongExtra("id", -1L)
        if (id < 0) return
        val app = context.applicationContext
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val dao = AppDatabase.get(app).orderDao()
                val o = dao.get(id)
                if (o != null && !o.done) {
                    val n = o.copy(done = true, doneAt = System.currentTimeMillis())
                    dao.upsert(n)
                    Reminders.schedule(app, n)
                }
                val mgr = AppWidgetManager.getInstance(app)
                val ids = mgr.getAppWidgetIds(ComponentName(app, TodayWidget::class.java))
                if (ids.isNotEmpty()) TodayWidget.render(app, mgr, ids)
            } finally {
                pending.finish()
            }
        }
    }
}
