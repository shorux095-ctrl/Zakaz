package uz.shoxrux.zakazlar.notify

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import uz.shoxrux.zakazlar.MainActivity
import uz.shoxrux.zakazlar.R
import uz.shoxrux.zakazlar.data.AppDatabase
import uz.shoxrux.zakazlar.data.Order
import uz.shoxrux.zakazlar.util.Dates
import java.time.LocalDate
import java.time.ZoneId

object Reminders {
    const val CHANNEL = "zakaz_eslatma"

    fun ensureChannel(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null) {
            val ch = NotificationChannel(CHANNEL, "Zakaz eslatmalari", NotificationManager.IMPORTANCE_HIGH)
            ch.description = "Zakaz muddati haqida eslatma"
            nm.createNotificationChannel(ch)
        }
    }

    fun triggerAt(o: Order): Long? {
        if (o.reminderMode == 0) return null
        val date = LocalDate.ofEpochDay(o.dateEpochDay)
        val t = o.timeMinutes
        val morning = date.atTime(8, 0)
        val dt = when {
            t == null -> morning
            o.reminderMode == 2 -> date.atTime(t / 60, t % 60)
            o.reminderMode == 3 -> date.atTime(t / 60, t % 60).minusHours(1)
            else -> morning
        }
        return dt.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
    }

    private fun alarmIntent(ctx: Context, id: Long): PendingIntent {
        val i = Intent(ctx, ReminderReceiver::class.java).putExtra("id", id)
        return PendingIntent.getBroadcast(
            ctx, id.toInt(), i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun cancel(ctx: Context, id: Long) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        am.cancel(alarmIntent(ctx, id))
    }

    fun schedule(ctx: Context, o: Order) {
        cancel(ctx, o.id)
        if (o.done) return
        val at = triggerAt(o) ?: return
        if (at <= System.currentTimeMillis()) return
        val am = ctx.getSystemService(AlarmManager::class.java)
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, alarmIntent(ctx, o.id))
    }

    @SuppressLint("MissingPermission")
    fun show(ctx: Context, o: Order) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) return
        ensureChannel(ctx)
        val open = PendingIntent.getActivity(
            ctx, o.id.toInt(),
            Intent(ctx, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val time = o.timeMinutes?.let { Dates.clock(it) + " · " } ?: ""
        val body = time + o.details.ifBlank { "Zakazni berish vaqti keldi" }
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(o.customer)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        NotificationManagerCompat.from(ctx).notify(o.id.toInt(), n)
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra("id", -1L)
        if (id < 0) return
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val o = AppDatabase.get(context).orderDao().get(id)
                if (o != null && !o.done) Reminders.show(context, o)
            } finally {
                pending.finish()
            }
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val list = AppDatabase.get(context).orderDao().pendingFrom(Dates.today())
                list.forEach { Reminders.schedule(context, it) }
            } finally {
                pending.finish()
            }
        }
    }
}
