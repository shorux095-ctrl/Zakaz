package uz.shoxrux.zakazlar.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.NotificationsOff
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import uz.shoxrux.zakazlar.data.Order
import uz.shoxrux.zakazlar.util.Dates
import uz.shoxrux.zakazlar.util.NameMatch

@Composable
fun EditorScreen(
    existing: Order?,
    defaultDay: Long,
    knownNames: List<Pair<String, Int>>,
    onSave: (Order, Boolean) -> Unit,
    onDelete: (Order) -> Unit,
    onClose: () -> Unit,
    presetCustomer: String = "",
    onOpenCustomer: (String) -> Unit = {},
) {
    val cs = MaterialTheme.colorScheme
    val ex = extra
    val today = Dates.today()
    val focusManager = LocalFocusManager.current

    var customer by rememberSaveable { mutableStateOf(existing?.customer ?: presetCustomer) }
    var savedCount by rememberSaveable { mutableStateOf(0) }
    var details by rememberSaveable { mutableStateOf(existing?.details ?: "") }
    var day by rememberSaveable { mutableStateOf(existing?.dateEpochDay ?: defaultDay) }
    var time by rememberSaveable { mutableStateOf(existing?.timeMinutes) }
    var reminder by rememberSaveable { mutableStateOf(existing?.reminderMode ?: 1) }
    var pickDay by remember { mutableStateOf(false) }
    var pickTime by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        if (existing == null) focus.requestFocus()
    }

    val suggestions = remember(customer, knownNames) { NameMatch.suggest(customer, knownNames) }

    val scroll = rememberScrollState()
    val scope = rememberCoroutineScope()

    fun close() {
        focusManager.clearFocus()
        onClose()
    }

    fun submit(more: Boolean) {
        val o = Order(
            id = existing?.id ?: 0L,
            customer = customer.trim(),
            details = details.trim(),
            dateEpochDay = day,
            timeMinutes = time,
            done = existing?.done ?: false,
            doneAt = existing?.doneAt,
            reminderMode = reminder,
            createdAt = existing?.createdAt ?: System.currentTimeMillis()
        )
        if (more) {
            onSave(o, true)
            customer = ""
            details = ""
            savedCount += 1
            scope.launch { scroll.animateScrollTo(0) }
            focus.requestFocus()
        } else {
            focusManager.clearFocus()
            onSave(o, false)
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(cs.background)
            .imePadding()
    ) {
        // ---- sarlavha ----
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
                .background(headerBrush())
                .statusBarsPadding()
                .padding(horizontal = 8.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { close() }) {
                Icon(Icons.Rounded.Close, null, tint = Color.White)
            }
            Column(
                Modifier
                    .weight(1f)
                    .padding(start = 4.dp)
            ) {
                Text(
                    if (existing == null) "Yangi zakaz" else "Zakazni tahrirlash",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                if (savedCount > 0) {
                    Text(
                        "$savedCount ta saqlandi",
                        color = ex.gold,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
            if (existing != null) {
                IconButton(onClick = { onOpenCustomer(existing.customer) }) {
                    Icon(Icons.Rounded.History, null, tint = Color.White.copy(alpha = 0.9f))
                }
                IconButton(onClick = { confirmDelete = true }) {
                    Icon(Icons.Rounded.Delete, null, tint = Color.White.copy(alpha = 0.9f))
                }
            }
        }

        // ---- forma ----
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(scroll)
                .padding(top = 20.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SectionLabel("Mijoz", Modifier.padding(horizontal = 20.dp))
            OutlinedTextField(
                value = customer,
                onValueChange = { customer = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .focusRequester(focus),
                label = { Text("Mijoz ismi") },
                leadingIcon = { Icon(Icons.Rounded.Person, null) },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.Words,
                    imeAction = ImeAction.Next
                ),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = cs.surface,
                    unfocusedContainerColor = cs.surface
                )
            )
            if (suggestions.isNotEmpty()) {
                Text(
                    if (customer.isBlank()) "Mijozlar" else "O'xshash ismlar",
                    modifier = Modifier.padding(horizontal = 22.dp),
                    fontSize = 12.sp,
                    color = cs.onSurfaceVariant
                )
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(suggestions) { n ->
                        Pill(n, false, { customer = n }, icon = Icons.Rounded.Person)
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            SectionLabel("Zakaz", Modifier.padding(horizontal = 20.dp))
            OutlinedTextField(
                value = details,
                onValueChange = { details = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                label = { Text("Nima va qancha (ixtiyoriy)") },
                placeholder = { Text("Masalan: 20 kg un, 2 ta yog'") },
                minLines = 3,
                maxLines = 6,
                shape = RoundedCornerShape(16.dp),
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = cs.surface,
                    unfocusedContainerColor = cs.surface
                )
            )

            Spacer(Modifier.height(8.dp))
            SectionLabel("Sana", Modifier.padding(horizontal = 20.dp))
            val quick = listOf(0L to "Bugun", 1L to "Ertaga", 3L to "3 kundan keyin", 7L to "1 hafta")
            LazyRow(
                contentPadding = PaddingValues(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(quick) { (off, label) ->
                    Pill(label, day == today + off, { day = today + off })
                }
                item {
                    val custom = quick.none { day == today + it.first }
                    Pill(
                        if (custom) Dates.short(day) else "Boshqa sana",
                        custom,
                        { pickDay = true },
                        icon = Icons.Rounded.CalendarMonth
                    )
                }
            }
            Row(
                Modifier.padding(horizontal = 22.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    Icons.Rounded.CalendarMonth, null,
                    Modifier.size(18.dp), tint = cs.onSurfaceVariant
                )
                Text(
                    Dates.label(day, today),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = cs.onSurface
                )
            }

            Spacer(Modifier.height(8.dp))
            SectionLabel("Vaqt", Modifier.padding(horizontal = 20.dp))
            val presets = listOf(9 * 60, 12 * 60, 15 * 60, 18 * 60)
            LazyRow(
                contentPadding = PaddingValues(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    Pill("Vaqtsiz", time == null, {
                        time = null
                        if (reminder >= 2) reminder = 1
                    })
                }
                items(presets) { m ->
                    Pill(Dates.clock(m), time == m, { time = m })
                }
                item {
                    val t = time
                    val custom = t != null && t !in presets
                    Pill(
                        if (custom && t != null) Dates.clock(t) else "Boshqa",
                        custom,
                        { pickTime = true },
                        icon = Icons.Rounded.Schedule
                    )
                }
            }

            Spacer(Modifier.height(8.dp))
            SectionLabel("Eslatma", Modifier.padding(horizontal = 20.dp))
            val opts = buildList {
                add(0 to "Yo'q")
                add(1 to "Ertalab 08:00")
                if (time != null) {
                    add(2 to "Vaqtida")
                    add(3 to "1 soat oldin")
                }
            }
            LazyRow(
                contentPadding = PaddingValues(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(opts) { (m, label) ->
                    Pill(
                        label,
                        reminder == m,
                        { reminder = m },
                        icon = if (m == 0) Icons.Rounded.NotificationsOff else Icons.Rounded.NotificationsActive
                    )
                }
            }
            Spacer(Modifier.height(24.dp))
        }

        // ---- saqlash ----
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
                .navigationBarsPadding(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (existing == null) {
                OutlinedButton(
                    onClick = { submit(true) },
                    enabled = customer.isNotBlank(),
                    modifier = Modifier
                        .weight(1f)
                        .height(56.dp),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Text("Saqlash va yana", fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                }
            }
            Button(
                onClick = { submit(false) },
                enabled = customer.isNotBlank(),
                modifier = Modifier
                    .weight(1f)
                    .height(56.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = ex.gold,
                    contentColor = ex.onGold,
                    disabledContainerColor = cs.surfaceVariant,
                    disabledContentColor = cs.onSurfaceVariant
                )
            ) {
                Text(
                    if (existing == null) "Saqlash" else "Yangilash",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }

    if (pickDay) {
        DayPickerDialog(initialDay = day, onPick = { day = it }, onDismiss = { pickDay = false })
    }
    if (pickTime) {
        ClockDialog(
            initialMinutes = time ?: (9 * 60),
            onPick = { time = it },
            onDismiss = { pickTime = false }
        )
    }
    if (confirmDelete && existing != null) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("O'chirilsinmi?") },
            text = { Text("${existing.customer} zakazi butunlay o'chiriladi.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    onDelete(existing)
                }) { Text("O'chirish", color = extra.danger) }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) { Text("Bekor") }
            }
        )
    }
}
