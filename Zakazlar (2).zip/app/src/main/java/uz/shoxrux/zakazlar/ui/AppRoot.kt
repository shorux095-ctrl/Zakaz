package uz.shoxrux.zakazlar.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import uz.shoxrux.zakazlar.MainViewModel
import uz.shoxrux.zakazlar.util.Dates
import uz.shoxrux.zakazlar.util.NameMatch

@Composable
fun AppRoot(vm: MainViewModel) {
    val orders by vm.orders.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme

    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    var editorOpen by rememberSaveable { mutableStateOf(false) }
    var editId by rememberSaveable { mutableStateOf(0L) }
    var newDay by rememberSaveable { mutableStateOf(Dates.today() + 1) }
    var newCustomer by rememberSaveable { mutableStateOf("") }
    var historyOf by rememberSaveable { mutableStateOf<String?>(null) }

    val known = remember(orders) {
        orders.map { it.customer.trim() }
            .filter { it.isNotEmpty() }
            .groupBy { NameMatch.norm(it) }
            .values
            .map { group ->
                val best = group.groupingBy { it }.eachCount().maxByOrNull { e -> e.value }!!.key
                best to group.size
            }
    }

    Box(Modifier.fillMaxSize().background(cs.background)) {
        HomeScreen(
            orders = orders,
            onAdd = { day ->
                editId = 0L
                newDay = day
                newCustomer = ""
                editorOpen = true
            },
            onOpen = {
                editId = it.id
                editorOpen = true
            },
            onToggle = { vm.toggleDone(it) },
            onOpenCustomer = { historyOf = it }
        )

        val hist = historyOf
        if (hist != null) {
            BackHandler { historyOf = null }
            Box(
                Modifier
                    .fillMaxSize()
                    .background(cs.background)
                    .pointerInput(Unit) { detectTapGestures { } }
            ) {
                CustomerScreen(
                    name = hist,
                    orders = orders,
                    onClose = { historyOf = null },
                    onOpen = {
                        editId = it.id
                        editorOpen = true
                    },
                    onToggle = { vm.toggleDone(it) },
                    onAddFor = { who ->
                        editId = 0L
                        newDay = Dates.today() + 1
                        newCustomer = who
                        editorOpen = true
                    }
                )
            }
        }

        if (editorOpen) {
            BackHandler { editorOpen = false }
            val existing = if (editId == 0L) null else orders.firstOrNull { it.id == editId }
            Box(
                Modifier
                    .fillMaxSize()
                    .background(cs.background)
                    .pointerInput(Unit) { detectTapGestures { } }
            ) {
                if (editId == 0L || existing != null) {
                    EditorScreen(
                        existing = existing,
                        defaultDay = newDay,
                        knownNames = known,
                        presetCustomer = newCustomer,
                        onOpenCustomer = {
                            editorOpen = false
                            historyOf = it
                        },
                        onSave = { o, more ->
                            vm.save(o)
                            if (!more) editorOpen = false
                        },
                        onDelete = {
                            vm.delete(it)
                            editorOpen = false
                        },
                        onClose = { editorOpen = false }
                    )
                }
            }
        }
    }
}
