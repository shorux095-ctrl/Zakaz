package uz.shoxrux.zakazlar

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import uz.shoxrux.zakazlar.data.AppDatabase
import uz.shoxrux.zakazlar.data.Order
import uz.shoxrux.zakazlar.notify.Reminders

class MainViewModel(private val app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).orderDao()

    val orders: StateFlow<List<Order>> =
        dao.observeAll().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun save(order: Order) {
        viewModelScope.launch {
            val id = dao.upsert(order)
            val saved = if (order.id == 0L) order.copy(id = id) else order
            Reminders.schedule(app, saved)
        }
    }

    fun toggleDone(o: Order) {
        viewModelScope.launch {
            val n = o.copy(done = !o.done, doneAt = if (!o.done) System.currentTimeMillis() else null)
            dao.upsert(n)
            if (n.done) Reminders.cancel(app, n.id) else Reminders.schedule(app, n)
        }
    }

    fun delete(o: Order) {
        viewModelScope.launch {
            dao.delete(o)
            Reminders.cancel(app, o.id)
        }
    }
}
