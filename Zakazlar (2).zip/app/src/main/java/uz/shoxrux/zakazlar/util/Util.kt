package uz.shoxrux.zakazlar.util

import java.time.LocalDate

object Dates {
    private val months = listOf(
        "yanvar", "fevral", "mart", "aprel", "may", "iyun",
        "iyul", "avgust", "sentabr", "oktabr", "noyabr", "dekabr"
    )
    private val weekdays = listOf(
        "Dushanba", "Seshanba", "Chorshanba", "Payshanba", "Juma", "Shanba", "Yakshanba"
    )

    fun today(): Long = LocalDate.now().toEpochDay()

    fun short(epoch: Long): String {
        val d = LocalDate.ofEpochDay(epoch)
        val year = if (d.year != LocalDate.now().year) " ${d.year}" else ""
        return "${d.dayOfMonth}-${months[d.monthValue - 1]}$year"
    }

    fun weekday(epoch: Long): String =
        weekdays[LocalDate.ofEpochDay(epoch).dayOfWeek.value - 1]

    fun full(epoch: Long): String = "${weekday(epoch)}, ${short(epoch)}"

    fun label(epoch: Long, today: Long): String {
        val prefix = when (epoch - today) {
            0L -> "Bugun · "
            1L -> "Ertaga · "
            -1L -> "Kecha · "
            else -> ""
        }
        return prefix + full(epoch)
    }

    fun clock(min: Int): String =
        (min / 60).toString().padStart(2, '0') + ":" + (min % 60).toString().padStart(2, '0')
}

/** Ismlarni o'xshashligi bo'yicha topish (imlo xatosi, apostrof, qisqa yozuvga chidamli). */
object NameMatch {
    private val spaces = Regex("\\s+")

    fun norm(s: String): String {
        val sb = StringBuilder()
        for (c in s.lowercase()) {
            when {
                c == '\u02BB' || c == '\u02BC' -> {}
                c.isLetterOrDigit() -> sb.append(c)
                c.isWhitespace() -> sb.append(' ')
            }
        }
        return sb.toString().trim().replace(spaces, " ")
    }

    private fun lev(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
            }
            val t = prev
            prev = cur
            cur = t
        }
        return prev[b.length]
    }

    /** null = mos emas; kichik son = yaxshiroq moslik. */
    fun score(query: String, name: String): Int? {
        val q = norm(query)
        if (q.isEmpty()) return 0
        val n = norm(name)
        if (n.isEmpty()) return null
        if (n == q) return 0
        if (n.startsWith(q)) return 1
        val tokens = n.split(' ')
        if (tokens.any { it.startsWith(q) }) return 2
        if (n.contains(q)) return 3
        if (q.length >= 3) {
            val maxD = if (q.length <= 4) 1 else 2
            var best = lev(q, n.take(q.length))
            for (t in tokens) {
                best = minOf(best, lev(q, t), lev(q, t.take(q.length)))
            }
            if (best <= maxD) return 4 + best
        }
        return null
    }

    fun suggest(query: String, names: List<Pair<String, Int>>, limit: Int = 8): List<String> {
        val q = query.trim()
        val scored = ArrayList<Triple<String, Int, Int>>()
        for ((name, count) in names) {
            if (name.trim() == q) continue
            val s = score(q, name) ?: continue
            scored.add(Triple(name, s, count))
        }
        return scored
            .sortedWith(compareBy<Triple<String, Int, Int>>({ it.second }, { -it.third }, { it.first }))
            .take(limit)
            .map { it.first }
    }
}
