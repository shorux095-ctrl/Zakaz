package uz.shoxrux.zakazlar.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import uz.shoxrux.zakazlar.data.Order
import uz.shoxrux.zakazlar.util.Dates
import uz.shoxrux.zakazlar.util.NameMatch

@Composable
fun CustomerScreen(
    name: String,
    orders: List<Order>,
    onClose: () -> Unit,
    onOpen: (Order) -> Unit,
    onToggle: (Order) -> Unit,
    onAddFor: (String) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val ex = extra
    val today = Dates.today()
    val key = NameMatch.norm(name)
    val list = orders
        .filter { NameMatch.norm(it.customer) == key }
        .sortedWith(compareByDescending<Order> { it.dateEpochDay }.thenByDescending { it.id })
    val shownName = list.firstOrNull()?.customer ?: name
    val total = list.size
    val done = list.count { it.done }
    val pending = total - done
    val groups = list.groupBy { it.dateEpochDay }

    Scaffold(
        containerColor = cs.background,
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { onAddFor(shownName) },
                containerColor = ex.gold,
                contentColor = ex.onGold,
                shape = RoundedCornerShape(20.dp)
            ) {
                Icon(Icons.Rounded.Add, null)
                Spacer(Modifier.width(8.dp))
                Text("Yangi zakaz", fontWeight = FontWeight.Bold)
            }
        }
    ) { inner ->
        Column(Modifier.fillMaxSize()) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
                    .background(headerBrush())
                    .statusBarsPadding()
                    .padding(start = 8.dp, end = 20.dp, top = 8.dp, bottom = 20.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onClose) {
                        Icon(Icons.Rounded.Close, null, tint = Color.White)
                    }
                    Column(Modifier.weight(1f)) {
                        Text(
                            "MIJOZ TARIXI",
                            color = ex.gold,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 2.sp
                        )
                        Text(
                            shownName,
                            color = Color.White,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                Spacer(Modifier.height(16.dp))
                Row(
                    Modifier.padding(start = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StatTile("Jami", total, false, {}, Modifier.weight(1f))
                    StatTile("Berilgan", done, false, {}, Modifier.weight(1f))
                    StatTile("Berilmagan", pending, true, {}, Modifier.weight(1f))
                }
            }

            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(
                    start = 16.dp, end = 16.dp, top = 8.dp,
                    bottom = inner.calculateBottomPadding() + 96.dp
                ),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (groups.isEmpty()) {
                    item(key = "empty") {
                        EmptyState("Zakaz yo'q", "Pastdagi tugma bilan yangi zakaz qo'shing")
                    }
                }
                for ((day, dayList) in groups) {
                    item(key = "h$day") { DayHeader(day, today, dayList) }
                    items(dayList, key = { it.id }) { o ->
                        OrderCard(
                            o = o,
                            today = today,
                            onClick = { onOpen(o) },
                            onToggle = { onToggle(o) }
                        )
                    }
                }
            }
        }
    }
}
