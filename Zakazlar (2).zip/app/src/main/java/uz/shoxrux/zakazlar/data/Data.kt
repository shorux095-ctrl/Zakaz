package uz.shoxrux.zakazlar.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "orders")
data class Order(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val customer: String,
    val details: String = "",
    val dateEpochDay: Long,
    val timeMinutes: Int? = null,
    val done: Boolean = false,
    val doneAt: Long? = null,
    /** 0 = eslatmasiz, 1 = ertalab 08:00, 2 = vaqtida, 3 = 1 soat oldin */
    val reminderMode: Int = 1,
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface OrderDao {
    @Query("SELECT * FROM orders ORDER BY dateEpochDay ASC, CASE WHEN timeMinutes IS NULL THEN 9999 ELSE timeMinutes END ASC, id ASC")
    fun observeAll(): Flow<List<Order>>

    @Query("SELECT * FROM orders WHERE id = :id")
    suspend fun get(id: Long): Order?

    @Query("SELECT * FROM orders WHERE done = 0 AND dateEpochDay >= :fromDay")
    suspend fun pendingFrom(fromDay: Long): List<Order>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(order: Order): Long

    @Delete
    suspend fun delete(order: Order)
}

@Database(entities = [Order::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun orderDao(): OrderDao

    companion object {
        @Volatile
        private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "zakazlar.db"
                ).build().also { instance = it }
            }
    }
}
