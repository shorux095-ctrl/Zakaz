package uz.shoxrux.zakazlar.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch
import uz.shoxrux.zakazlar.MainViewModel
import uz.shoxrux.zakazlar.data.Order
import uz.shoxrux.zakazlar.util.Dates
import uz.shoxrux.zakazlar.util.NameMatch

@Composable
fun AppRoot(vm: MainViewModel) {
    val orders by vm.orders.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme

    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    var editorOpen by rememberSaveable { mutableStateOf(false) }
    var editId by rememberSaveable { mutableStateOf(0L) }
    var newDay by rememberSaveable { mutableStateOf(Dates.today() + 1) }
    var newCustomer by rememberSaveable { mutableStateOf("") }
    var historyOf by rememberSaveable { mutableStateOf<String?>(null) }
    var listIds by remember { mutableStateOf<List<Long>?>(null) }

    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    fun deleteWithUndo(o: Order) {
        vm.delete(o)
        scope.launch {
            snackbar.currentSnackbarData?.dismiss()
            val r = snackbar.showSnackbar(
                message = "Zakaz o'chirildi",
                actionLabel = "Qaytarish",
                duration = SnackbarDuration.Long
            )
            if (r == SnackbarResult.ActionPerformed) vm.save(o)
        }
    }

    val known = remember(orders) {
        orders.map { it.customer.trim() }
            .filter { it.isNotEmpty() }
            .groupBy { NameMatch.norm(it) }
            .values
            .map { group ->
                val best = group.groupingBy { it }.eachCount().maxByOrNull { e -> e.value }!!.key
                best to group.size
            }
    }

    Box(Modifier.fillMaxSize().background(cs.background)) {
        HomeScreen(
            orders = orders,
            onAdd = { day ->
                editId = 0L
                newDay = day
                newCustomer = ""
                editorOpen = true
            },
            onOpen = {
                editId = it.id
                editorOpen = true
            },
            onToggle = { vm.toggleDone(it) },
            onOpenCustomer = { historyOf = it },
            onDelete = { deleteWithUndo(it) },
            onTogglePaid = { vm.togglePaid(it) },
            onMakeList = { listIds = it }
        )

        val hist = historyOf
        if (hist != null) {
            BackHandler { historyOf = null }
            Box(
                Modifier
                    .fillMaxSize()
                    .background(cs.background)
                    .pointerInput(Unit) { detectTapGestures { } }
            ) {
                CustomerScreen(
                    name = hist,
                    orders = orders,
                    onClose = { historyOf = null },
                    onOpen = {
                        editId = it.id
                        editorOpen = true
                    },
                    onToggle = { vm.toggleDone(it) },
                    onDelete = { deleteWithUndo(it) },
                    onTogglePaid = { vm.togglePaid(it) },
                    onAddFor = { who ->
                        editId = 0L
                        newDay = Dates.today() + 1
                        newCustomer = who
                        editorOpen = true
                    }
                )
            }
        }

        val ids = listIds
        if (ids != null) {
            BackHandler { listIds = null }
            Box(
                Modifier
                    .fillMaxSize()
                    .background(cs.background)
                    .pointerInput(Unit) { detectTapGestures { } }
            ) {
                ListScreen(
                    allOrders = orders,
                    initialIds = ids,
                    onEdit = {
                        editId = it.id
                        editorOpen = true
                    },
                    onSent = { vm.markSent(it) },
                    onClose = { listIds = null }
                )
            }
        }

        if (editorOpen) {
            BackHandler { editorOpen = false }
            val existing = if (editId == 0L) null else orders.firstOrNull { it.id == editId }
            Box(
                Modifier
                    .fillMaxSize()
                    .background(cs.background)
                    .pointerInput(Unit) { detectTapGestures { } }
            ) {
                if (editId == 0L || existing != null) {
                    EditorScreen(
                        existing = existing,
                        defaultDay = newDay,
                        knownNames = known,
                        presetCustomer = newCustomer,
                        onOpenCustomer = {
                            editorOpen = false
                            historyOf = it
                        },
                        onSave = { o, more ->
                            vm.save(o)
                            if (!more) editorOpen = false
                        },
                        onDelete = {
                            deleteWithUndo(it)
                            editorOpen = false
                        },
                        onClose = { editorOpen = false }
                    )
                }
            }
        }

        SnackbarHost(
            hostState = snackbar,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 80.dp)
        )
    }
}
