package uz.shoxrux.zakazlar.widget

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import uz.shoxrux.zakazlar.data.AppDatabase
import uz.shoxrux.zakazlar.data.Order
import uz.shoxrux.zakazlar.notify.Reminders
import uz.shoxrux.zakazlar.ui.Pill
import uz.shoxrux.zakazlar.ui.ZakazTheme
import uz.shoxrux.zakazlar.ui.extra
import uz.shoxrux.zakazlar.util.Dates
import uz.shoxrux.zakazlar.util.NameMatch

/** Vidjetdan ochiladigan kichik oyna: ilovaga kirmasdan tez zakaz yozish. */
class QuickAddActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val day = intent.getIntExtra(TodayWidget.EXTRA_DAY, 0)
        setContent {
            ZakazTheme {
                QuickAddScreen(
                    initialChoice = if (day == 1) 1 else 0,
                    onClose = { finish() }
                )
            }
        }
    }
}

@Composable
private fun QuickAddScreen(initialChoice: Int, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val app = ctx.applicationContext
    val cs = MaterialTheme.colorScheme
    val ex = extra
    val dao = remember { AppDatabase.get(app).orderDao() }
    val orders by dao.observeAll().collectAsStateWithLifecycle(initialValue = emptyList<Order>())
    val scope = rememberCoroutineScope()

    var customer by rememberSaveable { mutableStateOf("") }
    var details by rememberSaveable { mutableStateOf("") }
    // 0 = bugun, 1 = ertaga, 3 = 3 kundan keyin, -1 = keyinroq (sanasiz)
    var choice by rememberSaveable { mutableStateOf(initialChoice) }
    var saved by rememberSaveable { mutableStateOf(0) }

    val known = remember(orders) {
        orders.map { it.customer.trim() }
            .filter { it.isNotEmpty() }
            .groupBy { NameMatch.norm(it) }
            .values
            .map { g ->
                val best = g.groupingBy { it }.eachCount().maxByOrNull { e -> e.value }!!.key
                best to g.size
            }
    }
    val phones = remember(orders) {
        orders.filter { !it.phone.isNullOrBlank() }
            .sortedBy { it.createdAt }
            .associate { NameMatch.norm(it.customer) to (it.phone ?: "") }
    }
    val suggestions = remember(customer, known) { NameMatch.suggest(customer, known, 6) }

    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { focus.requestFocus() }

    fun save(more: Boolean) {
        val name = customer.trim()
        if (name.isEmpty()) return
        val later = choice == -1
        val day = if (later) Dates.today() else Dates.today() + choice
        val o = Order(
            customer = name,
            details = details.trim(),
            dateEpochDay = day,
            reminderMode = if (later) 0 else 1,
            later = later,
            phone = phones[NameMatch.norm(name)]
        )
        scope.launch {
            withContext(Dispatchers.IO) {
                val id = dao.upsert(o)
                Reminders.schedule(app, o.copy(id = id))
            }
            TodayWidget.refresh(app)
            if (more) {
                customer = ""
                details = ""
                saved += 1
                focus.requestFocus()
            } else {
                onClose()
            }
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.5f))
            .pointerInput(Unit) { detectTapGestures { onClose() } },
        contentAlignment = Alignment.BottomCenter
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .imePadding()
                .pointerInput(Unit) { detectTapGestures { } },
            shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
            color = cs.background
        ) {
            Column(
                Modifier.padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            "Tez zakaz yozish",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = cs.onBackground
                        )
                        if (saved > 0) {
                            Text(
                                "$saved ta saqlandi",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = ex.success
                            )
                        }
                    }
                    IconButton(onClick = onClose) {
                        Icon(Icons.Rounded.Close, null, tint = cs.onSurfaceVariant)
                    }
                }

                OutlinedTextField(
                    value = customer,
                    onValueChange = { customer = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(focus),
                    label = { Text("Mijoz ismi") },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.Words,
                        imeAction = ImeAction.Next
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = cs.surface,
                        unfocusedContainerColor = cs.surface
                    )
                )
                if (suggestions.isNotEmpty()) {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(suggestions) { n ->
                            Pill(n, false, { customer = n }, icon = Icons.Rounded.Person)
                        }
                    }
                }
                OutlinedTextField(
                    value = details,
                    onValueChange = { details = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Zakaz (ixtiyoriy)") },
                    minLines = 2,
                    maxLines = 4,
                    shape = RoundedCornerShape(16.dp),
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = cs.surface,
                        unfocusedContainerColor = cs.surface
                    )
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill("Bugun", choice == 0, { choice = 0 })
                    Pill("Ertaga", choice == 1, { choice = 1 })
                    Pill("3 kunda", choice == 3, { choice = 3 })
                    Pill("Keyinroq", choice == -1, { choice = -1 })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(
                        onClick = { save(true) },
                        enabled = customer.isNotBlank(),
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Text("Saqlash va yana", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Button(
                        onClick = { save(false) },
                        enabled = customer.isNotBlank(),
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ex.gold,
                            contentColor = ex.onGold,
                            disabledContainerColor = cs.surfaceVariant,
                            disabledContentColor = cs.onSurfaceVariant
                        )
                    ) {
                        Text("Saqlash", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
