package uz.shoxrux.zakazlar.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.net.Uri
import android.view.View
import android.widget.RemoteViews
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import uz.shoxrux.zakazlar.MainActivity
import uz.shoxrux.zakazlar.R
import uz.shoxrux.zakazlar.data.AppDatabase
import uz.shoxrux.zakazlar.data.Order
import uz.shoxrux.zakazlar.notify.Reminders
import uz.shoxrux.zakazlar.util.Dates

class TodayWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                render(context, appWidgetManager, appWidgetIds)
            } finally {
                pending.finish()
            }
        }
    }

    override fun onAppWidgetOptionsChanged(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int,
        newOptions: android.os.Bundle?
    ) {
        refresh(context)
    }

    companion object {
        const val ACTION_DONE = "uz.shoxrux.zakazlar.WIDGET_DONE"
        const val ACTION_TAB = "uz.shoxrux.zakazlar.WIDGET_TAB"
        const val EXTRA_DAY = "day"
        private const val MAX_ROWS = 10

        private val ROWS = intArrayOf(
            R.id.row0, R.id.row1, R.id.row2, R.id.row3, R.id.row4,
            R.id.row5, R.id.row6, R.id.row7, R.id.row8, R.id.row9
        )
        private val CHKS = intArrayOf(
            R.id.chk0, R.id.chk1, R.id.chk2, R.id.chk3, R.id.chk4,
            R.id.chk5, R.id.chk6, R.id.chk7, R.id.chk8, R.id.chk9
        )
        private val NAMES = intArrayOf(
            R.id.name0, R.id.name1, R.id.name2, R.id.name3, R.id.name4,
            R.id.name5, R.id.name6, R.id.name7, R.id.name8, R.id.name9
        )
        private val SUBS = intArrayOf(
            R.id.sub0, R.id.sub1, R.id.sub2, R.id.sub3, R.id.sub4,
            R.id.sub5, R.id.sub6, R.id.sub7, R.id.sub8, R.id.sub9
        )

        @Volatile
        private var cacheToday: List<Order>? = null

        @Volatile
        private var cacheTomorrow: List<Order>? = null

        private fun isCompact(mgr: AppWidgetManager, id: Int): Boolean {
            val w = mgr.getAppWidgetOptions(id).getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0)
            return w in 1..259
        }

        /** Bugun/Ertaga almashganda bazani kutmasdan darhol qayta chizadi. */
        fun switchTab(ctx: Context, tab: Int) {
            prefs(ctx).edit().putInt("tab", tab).apply()
            val t = cacheToday
            val tm = cacheTomorrow
            if (t == null || tm == null) return
            try {
                val mgr = AppWidgetManager.getInstance(ctx)
                val ids = mgr.getAppWidgetIds(ComponentName(ctx, TodayWidget::class.java))
                val today = Dates.today()
                for (id in ids) mgr.updateAppWidget(id, build(ctx, t, tm, today, tab, isCompact(mgr, id)))
            } catch (e: Exception) {
                // keyingi to'liq yangilanish tuzatadi
            }
        }

        /** ○ bosilganda zakaz vidjetdan darhol yo'qolishi uchun keshdan olib tashlaymiz. */
        fun dropFromCache(orderId: Long) {
            cacheToday = cacheToday?.filter { it.id != orderId }
            cacheTomorrow = cacheTomorrow?.filter { it.id != orderId }
        }

        fun prefs(ctx: Context): SharedPreferences =
            ctx.getSharedPreferences("widget", Context.MODE_PRIVATE)

        suspend fun render(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
            val dao = AppDatabase.get(ctx).orderDao()
            val today = Dates.today()
            val todayList = dao.widgetList(today)
            val tomorrowList = dao.widgetOn(today + 1)
            val tab = prefs(ctx).getInt("tab", 0)
            cacheToday = todayList
            cacheTomorrow = tomorrowList
            for (id in ids) {
                mgr.updateAppWidget(id, build(ctx, todayList, tomorrowList, today, tab, isCompact(mgr, id)))
            }
        }

        fun refresh(ctx: Context) {
            val app = ctx.applicationContext
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val mgr = AppWidgetManager.getInstance(app)
                    val ids = mgr.getAppWidgetIds(ComponentName(app, TodayWidget::class.java))
                    if (ids.isNotEmpty()) render(app, mgr, ids)
                } catch (e: Exception) {
                    // vidjet yangilanmasa ilova ishiga xalaqit bermasin
                }
            }
        }

        private fun openApp(ctx: Context): PendingIntent =
            PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )

        private fun quickAdd(ctx: Context, tab: Int): PendingIntent =
            PendingIntent.getActivity(
                ctx, 1,
                Intent(ctx, QuickAddActivity::class.java).putExtra(EXTRA_DAY, tab),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )

        private fun tabPi(ctx: Context, tab: Int): PendingIntent {
            val i = Intent(ctx, WidgetActionReceiver::class.java)
            i.action = ACTION_TAB
            i.data = Uri.parse("zakaz://tab/$tab")
            i.putExtra("tab", tab)
            return PendingIntent.getBroadcast(
                ctx, 0, i,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        }

        private fun donePi(ctx: Context, id: Long): PendingIntent {
            val i = Intent(ctx, WidgetActionReceiver::class.java)
            i.action = ACTION_DONE
            i.data = Uri.parse("zakaz://done/$id")
            i.putExtra("id", id)
            return PendingIntent.getBroadcast(
                ctx, 0, i,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        }

        private fun build(
            ctx: Context,
            todayList: List<Order>,
            tomorrowList: List<Order>,
            today: Long,
            tab: Int,
            compact: Boolean
        ): RemoteViews {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_today)
            val items = if (tab == 1) tomorrowList else todayList
            val count = items.size

            rv.setTextViewText(R.id.tab_today, "Bugun " + todayList.size)
            rv.setTextViewText(R.id.tab_tomorrow, "Ertaga " + tomorrowList.size)
            if (tab == 1) {
                rv.setInt(R.id.tab_today, "setBackgroundResource", R.drawable.widget_tab_off)
                rv.setTextColor(R.id.tab_today, Color.WHITE)
                rv.setInt(R.id.tab_tomorrow, "setBackgroundResource", R.drawable.widget_tab_on)
                rv.setTextColor(R.id.tab_tomorrow, Color.parseColor("#241A05"))
            } else {
                rv.setInt(R.id.tab_today, "setBackgroundResource", R.drawable.widget_tab_on)
                rv.setTextColor(R.id.tab_today, Color.parseColor("#241A05"))
                rv.setInt(R.id.tab_tomorrow, "setBackgroundResource", R.drawable.widget_tab_off)
                rv.setTextColor(R.id.tab_tomorrow, Color.WHITE)
            }
            rv.setOnClickPendingIntent(R.id.tab_today, tabPi(ctx, 0))
            rv.setOnClickPendingIntent(R.id.tab_tomorrow, tabPi(ctx, 1))

            rv.setTextViewText(R.id.widget_title, Dates.full(today + tab))
            rv.setOnClickPendingIntent(R.id.widget_title, openApp(ctx))
            rv.setTextViewText(R.id.widget_add, if (compact) "+" else if (tab == 1) "+ Ertaga" else "+ Bugun")
            rv.setOnClickPendingIntent(R.id.widget_add, quickAdd(ctx, tab))

            for (i in 0 until MAX_ROWS) {
                val o = items.getOrNull(i)
                if (o == null) {
                    rv.setViewVisibility(ROWS[i], View.GONE)
                } else {
                    val late = tab == 0 && o.dateEpochDay < today
                    val time = o.timeMinutes?.let { Dates.clock(it) + "  " } ?: ""
                    rv.setViewVisibility(ROWS[i], View.VISIBLE)
                    rv.setTextViewText(NAMES[i], time + o.customer)
                    rv.setTextColor(NAMES[i], if (late) Color.parseColor("#FF8A8A") else Color.WHITE)
                    val sub = buildString {
                        if (late) append((today - o.dateEpochDay).toString() + " kun o'tgan")
                        val firstLine = o.details.lineSequence().firstOrNull { it.isNotBlank() }
                        if (firstLine != null) {
                            if (isNotEmpty()) append(" · ")
                            append(firstLine.trim())
                        }
                    }
                    if (sub.isEmpty()) {
                        rv.setViewVisibility(SUBS[i], View.GONE)
                    } else {
                        rv.setViewVisibility(SUBS[i], View.VISIBLE)
                        rv.setTextViewText(SUBS[i], sub)
                    }
                    rv.setOnClickPendingIntent(CHKS[i], donePi(ctx, o.id))
                    rv.setOnClickPendingIntent(ROWS[i], openApp(ctx))
                }
            }

            if (count > MAX_ROWS) {
                rv.setViewVisibility(R.id.widget_more, View.VISIBLE)
                rv.setTextViewText(R.id.widget_more, "+" + (count - MAX_ROWS) + " ta yana, ilovada ko'ring")
                rv.setOnClickPendingIntent(R.id.widget_more, openApp(ctx))
            } else {
                rv.setViewVisibility(R.id.widget_more, View.GONE)
            }
            rv.setTextViewText(R.id.widget_empty, if (tab == 1) "Ertaga zakaz yo'q" else "Bugunga zakaz yo'q")
            rv.setViewVisibility(R.id.widget_empty, if (count == 0) View.VISIBLE else View.GONE)
            return rv
        }
    }
}

/** Vidjetdagi tugmalar: ○ (berilgan) va Bugun/Ertaga almashtirgich. */
class WidgetActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        if (action != TodayWidget.ACTION_DONE && action != TodayWidget.ACTION_TAB) return
        val app = context.applicationContext
        val id = intent.getLongExtra("id", -1L)
        val tab = intent.getIntExtra("tab", 0)
        if (action == TodayWidget.ACTION_TAB) {
            TodayWidget.switchTab(app, tab)
        } else if (id >= 0) {
            TodayWidget.dropFromCache(id)
            TodayWidget.switchTab(app, TodayWidget.prefs(app).getInt("tab", 0))
        }
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                if (action == TodayWidget.ACTION_TAB) {
                    TodayWidget.prefs(app).edit().putInt("tab", tab).apply()
                } else if (id >= 0) {
                    val dao = AppDatabase.get(app).orderDao()
                    val o = dao.get(id)
                    if (o != null && !o.done) {
                        val n = o.copy(done = true, doneAt = System.currentTimeMillis())
                        dao.upsert(n)
                        Reminders.schedule(app, n)
                    }
                }
                val mgr = AppWidgetManager.getInstance(app)
                val ids = mgr.getAppWidgetIds(ComponentName(app, TodayWidget::class.java))
                if (ids.isNotEmpty()) TodayWidget.render(app, mgr, ids)
            } finally {
                pending.finish()
            }
        }
    }
}
