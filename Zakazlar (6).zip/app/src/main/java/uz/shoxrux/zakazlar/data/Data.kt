package uz.shoxrux.zakazlar.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "orders")
data class Order(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val customer: String,
    val details: String = "",
    val dateEpochDay: Long,
    val timeMinutes: Int? = null,
    val done: Boolean = false,
    val doneAt: Long? = null,
    /** 0 = eslatmasiz, 1 = ertalab 08:00, 2 = vaqtida, 3 = 1 soat oldin */
    val reminderMode: Int = 1,
    val createdAt: Long = System.currentTimeMillis(),
    /** Mijoz pul beradigan sana (epoch day), yo'q bo'lsa null */
    val payDay: Long? = null,
    val paid: Boolean = false,
    val amount: Long? = null,
    /** Ishchilarga yuborilgan vaqt (millis), yuborilmagan bo'lsa null */
    val sentAt: Long? = null
)

@Dao
interface OrderDao {
    @Query("SELECT * FROM orders ORDER BY dateEpochDay ASC, CASE WHEN timeMinutes IS NULL THEN 9999 ELSE timeMinutes END ASC, id ASC")
    fun observeAll(): Flow<List<Order>>

    @Query("SELECT * FROM orders WHERE id = :id")
    suspend fun get(id: Long): Order?

    @Query("SELECT * FROM orders WHERE (done = 0 AND dateEpochDay >= :fromDay) OR (paid = 0 AND payDay IS NOT NULL AND payDay >= :fromDay)")
    suspend fun pendingFrom(fromDay: Long): List<Order>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(order: Order): Long

    @Delete
    suspend fun delete(order: Order)
}

@Database(entities = [Order::class], version = 3, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun orderDao(): OrderDao

    companion object {
        @Volatile
        private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "zakazlar.db"
                ).addMigrations(MIGRATION_1_2, MIGRATION_2_3).build().also { instance = it }
            }
    }
}

val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE orders ADD COLUMN payDay INTEGER")
        db.execSQL("ALTER TABLE orders ADD COLUMN paid INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE orders ADD COLUMN amount INTEGER")
    }
}

val MIGRATION_2_3 = object : Migration(2, 3) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE orders ADD COLUMN sentAt INTEGER")
    }
}
