package uz.shoxrux.zakazlar.ui

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import uz.shoxrux.zakazlar.data.Order
import uz.shoxrux.zakazlar.util.Dates
import uz.shoxrux.zakazlar.util.PdfExport
import uz.shoxrux.zakazlar.util.PdfRow

@Composable
fun ListScreen(initial: List<Order>, onClose: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val ex = extra
    val ctx = LocalContext.current
    val picked = remember { mutableStateListOf<Order>().apply { addAll(initial) } }
    var title by rememberSaveable { mutableStateOf("Zakazlar ro'yxati") }
    var big by rememberSaveable { mutableStateOf(false) }

    fun move(i: Int, d: Int) {
        val j = i + d
        if (i in picked.indices && j in picked.indices) {
            val t = picked[i]
            picked[i] = picked[j]
            picked[j] = t
        }
    }

    fun export(view: Boolean) {
        if (picked.isEmpty()) return
        try {
            val days = picked.map { it.dateEpochDay }.distinct()
            val sameDay = days.size == 1
            val rows = picked.mapIndexed { i, o ->
                val meta = buildList {
                    o.timeMinutes?.let { add("Vaqt: " + Dates.clock(it)) }
                    if (!sameDay) add("Sana: " + Dates.short(o.dateEpochDay))
                }.joinToString("  ·  ")
                PdfRow(i + 1, o.customer, o.details, meta)
            }
            val sub = if (sameDay) Dates.full(days[0]) else "Turli sanalar"
            val file = PdfExport.create(
                ctx,
                title.ifBlank { "Zakazlar ro'yxati" },
                sub,
                rows,
                if (big) 1.3f else 1f
            )
            val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", file)
            val intent = if (view) {
                Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "application/pdf")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
            } else {
                Intent.createChooser(
                    Intent(Intent.ACTION_SEND).apply {
                        type = "application/pdf"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        putExtra(Intent.EXTRA_SUBJECT, title)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    },
                    "Ishchilarga yuborish"
                )
            }
            ctx.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(ctx, "PDF ochilmadi: " + (e.message ?: ""), Toast.LENGTH_LONG).show()
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(cs.background)
            .imePadding()
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
                .background(headerBrush())
                .statusBarsPadding()
                .padding(start = 8.dp, end = 20.dp, top = 8.dp, bottom = 18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose) {
                Icon(Icons.Rounded.Close, null, tint = Color.White)
            }
            Column(Modifier.weight(1f)) {
                Text(
                    "ISH RO'YXATI",
                    color = ex.gold,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                )
                Text(
                    "${picked.size} ta zakaz",
                    color = Color.White,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        OutlinedTextField(
            value = title,
            onValueChange = { title = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 16.dp, top = 16.dp),
            label = { Text("Sarlavha") },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = cs.surface,
                unfocusedContainerColor = cs.surface
            )
        )
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("Katta yozuv", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = cs.onSurface)
                Text(
                    "Raqamlarni ↑ ↓ tugmalari bilan almashtiring",
                    fontSize = 12.sp,
                    color = cs.onSurfaceVariant
                )
            }
            Switch(checked = big, onCheckedChange = { big = it })
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            itemsIndexed(picked, key = { _, o -> o.id }) { i, o ->
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .animateItem(),
                    shape = RoundedCornerShape(18.dp),
                    color = cs.surface,
                    border = BorderStroke(1.dp, cs.outlineVariant),
                    shadowElevation = 1.dp
                ) {
                    Row(
                        Modifier.padding(start = 12.dp, top = 10.dp, bottom = 10.dp, end = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(ex.gold),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "${i + 1}",
                                color = ex.onGold,
                                fontWeight = FontWeight.Bold,
                                fontSize = 17.sp
                            )
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                o.customer,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = cs.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (o.details.isNotBlank()) {
                                Text(
                                    o.details,
                                    fontSize = 14.sp,
                                    color = cs.onSurfaceVariant,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                        IconButton(
                            onClick = { picked.remove(o) },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(Icons.Rounded.Close, null, tint = cs.onSurfaceVariant)
                        }
                        Column {
                            IconButton(
                                onClick = { move(i, -1) },
                                enabled = i > 0,
                                modifier = Modifier.size(36.dp)
                            ) { Icon(Icons.Rounded.KeyboardArrowUp, null) }
                            IconButton(
                                onClick = { move(i, 1) },
                                enabled = i < picked.size - 1,
                                modifier = Modifier.size(36.dp)
                            ) { Icon(Icons.Rounded.KeyboardArrowDown, null) }
                        }
                    }
                }
            }
        }

        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .navigationBarsPadding(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedButton(
                onClick = { export(true) },
                enabled = picked.isNotEmpty(),
                modifier = Modifier
                    .weight(0.8f)
                    .height(56.dp),
                shape = RoundedCornerShape(18.dp)
            ) {
                Text("Ko'rish", fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            }
            Button(
                onClick = { export(false) },
                enabled = picked.isNotEmpty(),
                modifier = Modifier
                    .weight(1.2f)
                    .height(56.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = ex.gold,
                    contentColor = ex.onGold,
                    disabledContainerColor = cs.surfaceVariant,
                    disabledContentColor = cs.onSurfaceVariant
                )
            ) {
                Icon(Icons.Rounded.Share, null, Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text("PDF yuborish", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
