package uz.shoxrux.zakazlar.util

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import java.io.File
import java.io.FileOutputStream

data class PdfRow(val number: Int, val name: String, val details: String, val meta: String)

object PdfExport {
    private const val PAGE_W = 595
    private const val PAGE_H = 842
    private const val M = 36f

    private fun paint(size: Float, bold: Boolean, color: Int): TextPaint {
        val p = TextPaint(Paint.ANTI_ALIAS_FLAG)
        p.textSize = size
        p.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        p.color = color
        return p
    }

    private fun layout(text: String, p: TextPaint, width: Int): StaticLayout =
        StaticLayout.Builder.obtain(text, 0, text.length, p, width)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setLineSpacing(0f, 1.05f)
            .build()

    private fun drawLayout(c: Canvas, l: StaticLayout, x: Float, y: Float) {
        c.save()
        c.translate(x, y)
        l.draw(c)
        c.restore()
    }

    fun create(ctx: Context, title: String, subtitle: String, rows: List<PdfRow>, scale: Float): File {
        val dir = File(ctx.cacheDir, "pdf")
        dir.mkdirs()
        dir.listFiles()?.forEach { it.delete() }
        val file = File(dir, "Ish_royxati_" + (System.currentTimeMillis() / 1000) + ".pdf")

        val ink = Color.parseColor("#1B2A49")
        val gray = Color.parseColor("#6B7080")
        val lineColor = Color.parseColor("#D5D0C3")
        val titleP = paint(30f, true, ink)
        val subP = paint(17f, false, gray)
        val contP = paint(13f, false, gray)
        val nameP = paint(26f * scale, true, Color.BLACK)
        val detP = paint(20f * scale, false, Color.parseColor("#222222"))
        val metaP = paint(16f * scale, false, gray)
        val numP = paint(24f, true, Color.WHITE)
        numP.textAlign = Paint.Align.CENTER
        val circleP = Paint(Paint.ANTI_ALIAS_FLAG)
        circleP.color = ink
        val linePaint = Paint()
        linePaint.color = lineColor
        linePaint.strokeWidth = 1.5f

        val numW = 60f
        val fullW = (PAGE_W - 2 * M).toInt()
        val textW = (PAGE_W - 2 * M - numW).toInt()

        val doc = PdfDocument()
        var pageNo = 0
        var page: PdfDocument.Page? = null
        var canvas = Canvas()
        var y = M

        fun startPage() {
            page?.let { doc.finishPage(it) }
            pageNo += 1
            val p = doc.startPage(PdfDocument.PageInfo.Builder(PAGE_W, PAGE_H, pageNo).create())
            page = p
            canvas = p.canvas
            y = M
            if (pageNo == 1) {
                val tl = layout(title, titleP, fullW)
                drawLayout(canvas, tl, M, y)
                y += tl.height + 4f
                if (subtitle.isNotBlank()) {
                    val sl = layout(subtitle, subP, fullW)
                    drawLayout(canvas, sl, M, y)
                    y += sl.height + 8f
                }
                canvas.drawLine(M, y, PAGE_W - M, y, linePaint)
                y += 16f
            } else {
                val cl = layout("$title (davomi)", contP, fullW)
                drawLayout(canvas, cl, M, y)
                y += cl.height + 14f
            }
        }

        startPage()
        for (r in rows) {
            val nameL = layout(r.name, nameP, textW)
            val detL = if (r.details.isNotBlank()) layout(r.details, detP, textW) else null
            val metaL = if (r.meta.isNotBlank()) layout(r.meta, metaP, textW) else null
            var h = nameL.height.toFloat()
            if (detL != null) h += 6f + detL.height
            if (metaL != null) h += 6f + metaL.height
            h = maxOf(h, 44f) + 24f
            if (y + h > PAGE_H - M && y > M + 60f) startPage()

            val top = y
            val cx = M + 22f
            val cy = top + 22f
            canvas.drawCircle(cx, cy, 22f, circleP)
            val fm = numP.fontMetrics
            canvas.drawText(r.number.toString(), cx, cy - (fm.ascent + fm.descent) / 2f, numP)

            var ty = top
            drawLayout(canvas, nameL, M + numW, ty)
            ty += nameL.height + 6f
            if (detL != null) {
                drawLayout(canvas, detL, M + numW, ty)
                ty += detL.height + 6f
            }
            if (metaL != null) {
                drawLayout(canvas, metaL, M + numW, ty)
            }
            y = top + h
            canvas.drawLine(M, y - 10f, PAGE_W - M, y - 10f, linePaint)
        }
        page?.let { doc.finishPage(it) }
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        return file
    }
}
