package uz.shoxrux.zakazlar.ui

import android.content.Intent
import android.widget.Toast
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import uz.shoxrux.zakazlar.util.QtySum
import uz.shoxrux.zakazlar.util.Telegram
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.core.content.FileProvider
import uz.shoxrux.zakazlar.data.Order
import uz.shoxrux.zakazlar.util.Dates
import uz.shoxrux.zakazlar.util.Money
import uz.shoxrux.zakazlar.util.MoneyText
import uz.shoxrux.zakazlar.util.PdfExport
import uz.shoxrux.zakazlar.util.PdfRow

@Composable
fun ListScreen(
    allOrders: List<Order>,
    initialIds: List<Long>,
    onEdit: (Order) -> Unit,
    onSent: (List<Long>) -> Unit,
    onClose: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val ex = extra
    val ctx = LocalContext.current

    val ids = remember { mutableStateListOf<Long>().apply { addAll(initialIds) } }
    val byId = allOrders.associateBy { it.id }
    val picked: List<Order> = ids.mapNotNull { byId[it] }

    var title by rememberSaveable { mutableStateOf("Zakazlar ro'yxati") }
    var big by rememberSaveable { mutableStateOf(false) }
    var showMoney by rememberSaveable { mutableStateOf(true) }
    var showPhone by rememberSaveable { mutableStateOf(true) }
    var showTg by remember { mutableStateOf(false) }
    var sending by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val listState = rememberLazyListState()
    var dragId by remember { mutableStateOf<Long?>(null) }
    var dragOffset by remember { mutableStateOf(0f) }
    var lastSwap by remember { mutableStateOf(0L) }

    fun moveBy(id: Long, d: Int) {
        val a = ids.indexOf(id)
        val b = a + d
        if (a >= 0 && b in ids.indices) {
            val t = ids.removeAt(a)
            ids.add(b, t)
        }
    }

    fun detailsOf(o: Order): String =
        if (showMoney) o.details else MoneyText.strip(o.details)

    fun moneyText(o: Order): String {
        val a = o.amount
        return if (showMoney && a != null && !o.paid) "Pul: " + Money.fmt(a) + " so'm" else ""
    }

    fun export(view: Boolean) {
        if (picked.isEmpty()) return
        try {
            val days = picked.map { it.dateEpochDay }.distinct()
            val sameDay = days.size == 1
            val rows = picked.mapIndexed { i, o ->
                val meta = buildList {
                    o.timeMinutes?.let { add("Vaqt: " + Dates.clock(it)) }
                    if (!sameDay) add("Sana: " + Dates.short(o.dateEpochDay))
                    if (showPhone && !o.phone.isNullOrBlank()) add("Tel: " + o.phone)
                }.joinToString("  ·  ")
                PdfRow(i + 1, o.customer, detailsOf(o), meta, moneyText(o))
            }
            val sub = if (sameDay) Dates.full(days[0]) else "Turli sanalar"
            val file = PdfExport.create(
                ctx,
                title.ifBlank { "Zakazlar ro'yxati" },
                sub,
                rows,
                if (big) 1.3f else 1f
            )
            val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", file)
            val intent = if (view) {
                Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "application/pdf")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
            } else {
                Intent.createChooser(
                    Intent(Intent.ACTION_SEND).apply {
                        type = "application/pdf"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        putExtra(Intent.EXTRA_SUBJECT, title)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    },
                    "Ishchilarga yuborish"
                )
            }
            ctx.startActivity(intent)
            if (!view) onSent(picked.map { it.id })
        } catch (e: Exception) {
            Toast.makeText(ctx, "PDF ochilmadi: " + (e.message ?: ""), Toast.LENGTH_LONG).show()
        }
    }

    fun moneyOf(o: Order): Long? {
        if (!showMoney) return null
        val a = o.amount
        if (a != null && !o.paid) return a
        var sum = 0L
        var found = false
        for (r in MoneyText.ranges(o.details)) {
            val digits = o.details.substring(r.first, r.last + 1).filter { it.isDigit() }.take(12)
            val v = digits.toLongOrNull()
            if (v != null) {
                sum += v
                found = true
            }
        }
        return if (found) sum else null
    }

    fun productText(o: Order): String =
        MoneyText.strip(o.details).lines()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .joinToString(", ")

    fun summaryLines(): List<String> {
        val out = ArrayList<String>()
        out.add("Zakazlar: ${picked.size} ta")
        for ((label, n) in QtySum.sum(picked.map { it.details })) {
            out.add(label + ": " + n + if (label.contains("(")) "" else " ta")
        }
        val total = picked.mapNotNull { moneyOf(it) }.sum()
        if (showMoney && total > 0) out.add("Pul: " + Money.fmt(total))
        return out
    }

    fun subtitle(): String {
        val days = picked.map { it.dateEpochDay }.distinct()
        return if (days.size == 1) Dates.full(days[0]) else "Turli sanalar"
    }

    fun buildText(): String {
        val sameDay = picked.map { it.dateEpochDay }.distinct().size == 1
        val sb = StringBuilder()
        sb.append(title.ifBlank { "Zakazlar ro'yxati" }).append("\n")
        sb.append(subtitle()).append("\n\n")
        picked.forEachIndexed { i, o ->
            sb.append(i + 1).append(". ").append(o.customer).append("\n")
            val pt = productText(o)
            if (pt.isNotEmpty()) sb.append("   ").append(pt).append("\n")
            val mv = moneyOf(o)
            if (mv != null) sb.append("   Pul: ").append(Money.fmt(mv)).append("\n")
            o.timeMinutes?.let { sb.append("   Vaqt: ").append(Dates.clock(it)).append("\n") }
            if (!sameDay) sb.append("   Sana: ").append(Dates.short(o.dateEpochDay)).append("\n")
            if (showPhone && !o.phone.isNullOrBlank()) sb.append("   Tel: ").append(o.phone).append("\n")
            sb.append("\n")
        }
        sb.append("Jami\n")
        for (l in summaryLines()) sb.append(l).append("\n")
        return sb.toString().trimEnd()
    }

    /** Telegram uchun oddiy va aniq xabar: qalin ism, ostida zakaz, pul alohida qatorda. */
    fun htmlMessages(): List<String> {
        val sameDay = picked.map { it.dateEpochDay }.distinct().size == 1
        val head = "<b>" + Telegram.esc(title.ifBlank { "Zakazlar ro'yxati" }).uppercase() + "</b>\n" +
            "<i>" + Telegram.esc(subtitle()) + "</i>\n\n"

        val footer = StringBuilder("────────────\n<b>JAMI</b>\n")
        for (l in summaryLines()) footer.append(Telegram.esc(l)).append("\n")

        val blocks = picked.mapIndexed { i, o ->
            val sb = StringBuilder()
            sb.append("<b>").append(i + 1).append(". ").append(Telegram.esc(o.customer)).append("</b>\n")
            val pt = productText(o)
            if (pt.isNotEmpty()) sb.append(Telegram.esc(pt)).append("\n")
            o.timeMinutes?.let { sb.append("🕐 ").append(Dates.clock(it)).append("\n") }
            if (!sameDay) sb.append("📅 ").append(Dates.short(o.dateEpochDay)).append("\n")
            if (showPhone && !o.phone.isNullOrBlank()) {
                sb.append("📞 ").append(Telegram.esc(o.phone ?: "")).append("\n")
            }
            val mv = moneyOf(o)
            if (mv != null) sb.append("💰 <b>Pul: ").append(Money.fmt(mv)).append("</b>\n")
            sb.append("\n")
            sb.toString()
        }

        val msgs = ArrayList<String>()
        var cur = StringBuilder(head)
        for (blk in blocks) {
            if (cur.length + blk.length > 2800 && cur.length > head.length) {
                msgs.add(cur.toString().trimEnd())
                cur = StringBuilder()
            }
            cur.append(blk)
        }
        cur.append(footer)
        msgs.add(cur.toString().trimEnd())
        return msgs
    }

    fun sendTelegram() {
        if (picked.isEmpty() || sending) return
        if (!Telegram.isConfigured(ctx)) {
            showTg = true
            return
        }
        val msgs = htmlMessages()
        val ids = picked.map { it.id }
        sending = true
        scope.launch {
            var err: String? = null
            withContext(Dispatchers.IO) {
                for (m in msgs) {
                    err = Telegram.send(ctx, m)
                    if (err != null) break
                }
            }
            sending = false
            if (err == null) {
                Toast.makeText(ctx, "Telegramga yuborildi", Toast.LENGTH_SHORT).show()
                onSent(ids)
            } else {
                Toast.makeText(ctx, "Yuborilmadi: " + err, Toast.LENGTH_LONG).show()
            }
        }
    }

    fun shareText() {
        if (picked.isEmpty()) return
        try {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, buildText())
                putExtra(Intent.EXTRA_SUBJECT, title)
            }
            ctx.startActivity(Intent.createChooser(send, "Ishchilarga yuborish"))
            onSent(picked.map { it.id })
        } catch (e: Exception) {
            Toast.makeText(ctx, "Yuborib bo'lmadi: " + (e.message ?: ""), Toast.LENGTH_LONG).show()
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(cs.background)
            .imePadding()
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
                .background(headerBrush())
                .statusBarsPadding()
                .padding(start = 8.dp, end = 20.dp, top = 8.dp, bottom = 18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose) {
                Icon(Icons.Rounded.Close, null, tint = Color.White)
            }
            Column(Modifier.weight(1f)) {
                Text(
                    "ISH RO'YXATI",
                    color = ex.gold,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                )
                Text(
                    "${picked.size} ta zakaz",
                    color = Color.White,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            IconButton(onClick = { showTg = true }) {
                Icon(Icons.Rounded.Settings, null, tint = Color.White)
            }
        }

        OutlinedTextField(
            value = title,
            onValueChange = { title = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 16.dp, top = 16.dp),
            label = { Text("Sarlavha") },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = cs.surface,
                unfocusedContainerColor = cs.surface
            )
        )
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Katta yozuv",
                modifier = Modifier.weight(1f),
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                color = cs.onSurface
            )
            Switch(checked = big, onCheckedChange = { big = it })
        }
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Pulni ko'rsatish (qizil)",
                modifier = Modifier.weight(1f),
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                color = cs.onSurface
            )
            Switch(checked = showMoney, onCheckedChange = { showMoney = it })
        }
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Telefon raqamini ko'rsatish",
                modifier = Modifier.weight(1f),
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                color = cs.onSurface
            )
            Switch(checked = showPhone, onCheckedChange = { showPhone = it })
        }
        Text(
            "Ismni bosib turib suring. Bossangiz tahrirlanadi.",
            modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 4.dp),
            fontSize = 12.sp,
            color = cs.onSurfaceVariant
        )

        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            itemsIndexed(picked, key = { _, o -> o.id }) { i, o ->
                val dragging = dragId == o.id
                val itemMod = if (dragging) {
                    Modifier
                        .zIndex(1f)
                        .graphicsLayer {
                            translationY = dragOffset
                            scaleX = 1.03f
                            scaleY = 1.03f
                        }
                } else {
                    Modifier.animateItem()
                }
                val money = moneyText(o)
                Surface(
                    onClick = { onEdit(o) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .pointerInput(o.id) {
                            detectDragGesturesAfterLongPress(
                                onDragStart = {
                                    dragId = o.id
                                    dragOffset = 0f
                                },
                                onDrag = { change, amount ->
                                    change.consume()
                                    dragOffset += amount.y
                                    val info = listState.layoutInfo.visibleItemsInfo
                                    val cur = info.firstOrNull { it.key == o.id }
                                    if (cur != null) {
                                        val now = System.currentTimeMillis()
                                        val center = cur.offset + dragOffset + cur.size / 2f
                                        val target = info.firstOrNull {
                                            it.key != o.id &&
                                                center >= it.offset &&
                                                center <= it.offset + it.size
                                        }
                                        if (target != null && now - lastSwap > 70) {
                                            val from = ids.indexOf(o.id)
                                            val to = ids.indexOf(target.key as Long)
                                            if (from >= 0 && to >= 0 && from != to) {
                                                val newOffset = if (to > from) {
                                                    target.offset + target.size - cur.size
                                                } else {
                                                    target.offset
                                                }
                                                val moved = ids.removeAt(from)
                                                ids.add(to, moved)
                                                dragOffset += (cur.offset - newOffset)
                                                lastSwap = now
                                            }
                                        }
                                        val top = cur.offset + dragOffset
                                        val bottom = top + cur.size
                                        val viewStart = listState.layoutInfo.viewportStartOffset
                                        val viewEnd = listState.layoutInfo.viewportEndOffset
                                        val delta = when {
                                            top < viewStart + 40 -> -18f
                                            bottom > viewEnd - 40 -> 18f
                                            else -> 0f
                                        }
                                        if (delta != 0f) {
                                            val used = listState.dispatchRawDelta(delta)
                                            dragOffset += used
                                        }
                                    }
                                },
                                onDragEnd = {
                                    dragId = null
                                    dragOffset = 0f
                                },
                                onDragCancel = {
                                    dragId = null
                                    dragOffset = 0f
                                }
                            )
                        }
                        .then(itemMod),
                    shape = RoundedCornerShape(18.dp),
                    color = cs.surface,
                    border = BorderStroke(
                        if (dragging) 2.dp else 1.dp,
                        if (dragging) ex.gold else cs.outlineVariant
                    ),
                    shadowElevation = if (dragging) 8.dp else 1.dp
                ) {
                    Row(
                        Modifier.padding(start = 12.dp, top = 10.dp, bottom = 10.dp, end = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(ex.gold),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "${i + 1}",
                                color = ex.onGold,
                                fontWeight = FontWeight.Bold,
                                fontSize = 17.sp
                            )
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                o.customer,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = cs.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (detailsOf(o).isNotBlank()) {
                                Text(
                                    redMoney(detailsOf(o)),
                                    fontSize = 14.sp,
                                    color = cs.onSurfaceVariant,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            if (money.isNotEmpty()) {
                                Text(
                                    money,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = ex.danger
                                )
                            }
                        }
                        IconButton(
                            onClick = { ids.remove(o.id) },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(Icons.Rounded.Close, null, tint = cs.onSurfaceVariant)
                        }
                        Column {
                            IconButton(
                                onClick = { moveBy(o.id, -1) },
                                enabled = i > 0,
                                modifier = Modifier.size(36.dp)
                            ) { Icon(Icons.Rounded.KeyboardArrowUp, null) }
                            IconButton(
                                onClick = { moveBy(o.id, 1) },
                                enabled = i < picked.size - 1,
                                modifier = Modifier.size(36.dp)
                            ) { Icon(Icons.Rounded.KeyboardArrowDown, null) }
                        }
                    }
                }
            }
        }

        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { sendTelegram() },
                enabled = picked.isNotEmpty() && !sending,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = ex.gold,
                    contentColor = ex.onGold,
                    disabledContainerColor = cs.surfaceVariant,
                    disabledContentColor = cs.onSurfaceVariant
                )
            ) {
                Icon(Icons.Rounded.Share, null, Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text(
                    if (sending) "Yuborilmoqda..." else "Telegramga yuborish",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { shareText() },
                    enabled = picked.isNotEmpty(),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text("Matn", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
                OutlinedButton(
                    onClick = { export(true) },
                    enabled = picked.isNotEmpty(),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text("PDF ko'rish", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
                OutlinedButton(
                    onClick = { export(false) },
                    enabled = picked.isNotEmpty(),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text("PDF yuborish", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }

    if (showTg) {
        TelegramDialog(onDismiss = { showTg = false })
    }
}
