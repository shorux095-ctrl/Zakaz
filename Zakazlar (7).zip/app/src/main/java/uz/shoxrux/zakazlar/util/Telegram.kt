package uz.shoxrux.zakazlar.util

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Telegram Bot API orqali ro'yxatni to'g'ridan-to'g'ri guruhga yoki ishchiga yuborish. */
object Telegram {
    data class Chat(val id: String, val title: String)

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("tg", Context.MODE_PRIVATE)

    fun token(ctx: Context): String = prefs(ctx).getString("token", "") ?: ""
    fun chatId(ctx: Context): String = prefs(ctx).getString("chat", "") ?: ""
    fun chatTitle(ctx: Context): String = prefs(ctx).getString("title", "") ?: ""

    fun save(ctx: Context, token: String, chatId: String, title: String) {
        prefs(ctx).edit()
            .putString("token", token.trim())
            .putString("chat", chatId.trim())
            .putString("title", title)
            .apply()
    }

    fun isConfigured(ctx: Context): Boolean = token(ctx).isNotBlank() && chatId(ctx).isNotBlank()

    fun esc(s: String): String = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    private fun call(token: String, method: String, params: Map<String, String>): String {
        val conn = URL("https://api.telegram.org/bot$token/$method").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 10000
            conn.readTimeout = 15000
            conn.doOutput = true
            val body = params.entries.joinToString("&") {
                URLEncoder.encode(it.key, "UTF-8") + "=" + URLEncoder.encode(it.value, "UTF-8")
            }
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            return stream?.bufferedReader()?.use { it.readText() } ?: ""
        } finally {
            conn.disconnect()
        }
    }

    private fun chunk(text: String): List<String> {
        if (text.length <= 3800) return listOf(text)
        val out = ArrayList<String>()
        val sb = StringBuilder()
        for (line in text.split("\n")) {
            if (sb.length + line.length + 1 > 3800 && sb.isNotEmpty()) {
                out.add(sb.toString())
                sb.clear()
            }
            sb.append(line).append("\n")
        }
        if (sb.isNotEmpty()) out.add(sb.toString())
        return out
    }

    /** Muvaffaqiyatli bo'lsa null, aks holda xato matni. */
    fun send(ctx: Context, html: String): String? {
        val token = token(ctx)
        val chat = chatId(ctx)
        if (token.isBlank() || chat.isBlank()) return "Telegram sozlanmagan"
        return try {
            for (part in chunk(html)) {
                val resp = JSONObject(
                    call(
                        token, "sendMessage",
                        mapOf(
                            "chat_id" to chat,
                            "text" to part,
                            "parse_mode" to "HTML",
                            "disable_web_page_preview" to "true"
                        )
                    )
                )
                if (!resp.optBoolean("ok", false)) {
                    return resp.optString("description", "Noma'lum xato")
                }
            }
            null
        } catch (e: Exception) {
            "Internet yoki ulanish xatosi"
        }
    }

    /** Bot yozishmalaridan chat ID larni topadi. */
    fun findChats(token: String): Pair<List<Chat>, String?> {
        return try {
            val root = JSONObject(call(token, "getUpdates", mapOf("limit" to "100", "timeout" to "0")))
            if (!root.optBoolean("ok", false)) {
                return Pair(emptyList(), root.optString("description", "Token noto'g'ri"))
            }
            val arr = root.optJSONArray("result") ?: JSONArray()
            val seen = LinkedHashMap<String, String>()
            for (i in 0 until arr.length()) {
                val u = arr.getJSONObject(i)
                for (key in listOf("message", "edited_message", "channel_post", "my_chat_member")) {
                    val chat = u.optJSONObject(key)?.optJSONObject("chat") ?: continue
                    val id = chat.optLong("id").toString()
                    var title = chat.optString("title")
                    if (title.isBlank()) {
                        title = (chat.optString("first_name") + " " + chat.optString("last_name")).trim()
                    }
                    seen[id] = if (title.isBlank()) id else title
                }
            }
            Pair(seen.map { Chat(it.key, it.value) }, null)
        } catch (e: Exception) {
            Pair(emptyList(), "Internet yoki ulanish xatosi")
        }
    }
}

/** "10 mayda", "50 mayda", "20 kg un" kabi matnlardan mahsulot bo'yicha jami sonni hisoblaydi. */
object QtySum {
    private val units = setOf(
        "kg", "ta", "dona", "litr", "l", "gr", "g", "sm", "m", "metr", "qop", "quti", "pochka"
    )
    private val numWord = Regex("(\\d+)\\s+([\\p{L}'\u2019\u02BB\u02BC`]+)")
    private val firstWord = Regex("^[\\p{L}'\u2019\u02BB\u02BC`]+")

    fun sum(details: List<String>): List<Pair<String, Int>> {
        val map = LinkedHashMap<String, Int>()
        for (d in details) {
            for (line in d.lines()) {
                if (MoneyText.isMoneyLine(line)) continue
                for (m in numWord.findAll(line)) {
                    val n = m.groupValues[1].toIntOrNull() ?: continue
                    val w = m.groupValues[2].lowercase()
                    var key = w
                    if (w in units) {
                        val rest = line.substring(m.range.last + 1).trim()
                        val next = firstWord.find(rest)?.value?.lowercase()
                        key = if (next != null) "$next ($w)" else w
                    }
                    map[key] = (map[key] ?: 0) + n
                }
            }
        }
        return map.map { (k, v) -> k.replaceFirstChar { it.uppercase() } to v }
    }
}
