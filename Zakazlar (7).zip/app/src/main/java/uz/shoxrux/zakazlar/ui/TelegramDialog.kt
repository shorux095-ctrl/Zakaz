package uz.shoxrux.zakazlar.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import uz.shoxrux.zakazlar.util.Telegram

@Composable
fun TelegramDialog(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()

    var token by remember { mutableStateOf(Telegram.token(ctx)) }
    var chatId by remember { mutableStateOf(Telegram.chatId(ctx)) }
    var chatTitle by remember { mutableStateOf(Telegram.chatTitle(ctx)) }
    var status by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var chats by remember { mutableStateOf<List<Telegram.Chat>>(emptyList()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Telegram ulash") },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    "1) Telegramda @BotFather ga yozing: /newbot, yangi bot yarating va tokenini oling.\n" +
                        "2) Botni ishchilar guruhiga qo'shing (guruhda admin qiling) yoki o'zingiz botga /start yozing.\n" +
                        "3) Guruhda yoki botga biror xabar yozing va pastdagi \"Chat ID ni topish\" ni bosing.\n\n" +
                        "Diqqat: bu ilova uchun YANGI bot oching, boshqa ishlayotgan botingizning tokenini qo'ymang.",
                    fontSize = 13.sp,
                    color = cs.onSurfaceVariant
                )
                OutlinedTextField(
                    value = token,
                    onValueChange = { token = it.trim() },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Bot tokeni") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp)
                )
                OutlinedButton(
                    onClick = {
                        scope.launch {
                            busy = true
                            status = "Qidirilmoqda..."
                            val res = withContext(Dispatchers.IO) { Telegram.findChats(token) }
                            busy = false
                            chats = res.first
                            val err = res.second
                            status = when {
                                err != null -> err
                                res.first.isEmpty() ->
                                    "Hech narsa topilmadi. Guruhda yoki botga xabar yozing va qayta bosing"
                                else -> "Chatni tanlang"
                            }
                        }
                    },
                    enabled = token.isNotBlank() && !busy,
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Chat ID ni topish") }

                for (c in chats) {
                    Pill(
                        c.title + " (" + c.id + ")",
                        chatId == c.id,
                        {
                            chatId = c.id
                            chatTitle = c.title
                        }
                    )
                }

                OutlinedTextField(
                    value = chatId,
                    onValueChange = { chatId = it.trim() },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Chat ID") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp)
                )
                if (chatTitle.isNotBlank()) {
                    Text("Tanlangan: $chatTitle", fontSize = 13.sp, color = cs.onSurface)
                }
                OutlinedButton(
                    onClick = {
                        scope.launch {
                            busy = true
                            status = "Yuborilmoqda..."
                            Telegram.save(ctx, token, chatId, chatTitle)
                            val err = withContext(Dispatchers.IO) {
                                Telegram.send(ctx, "Zakazlar ilovasi ulandi")
                            }
                            busy = false
                            status = err ?: "Test xabar yuborildi"
                        }
                    },
                    enabled = token.isNotBlank() && chatId.isNotBlank() && !busy,
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Test xabar yuborish") }
                if (status.isNotEmpty()) {
                    Text(status, fontSize = 13.sp, color = cs.onSurfaceVariant)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                Telegram.save(ctx, token, chatId, chatTitle)
                onDismiss()
            }) { Text("Saqlash") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor") } }
    )
}
