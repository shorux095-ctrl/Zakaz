# Zakazlar

Mijoz zakazlarini sana va vaqt bilan yozib boradigan Android ilova (Kotlin + Jetpack Compose + Room).

## APK qilish (GitHub Actions)
1. GitHub'da yangi repo oching (Daftarapp'dan alohida).
2. Shu papkadagi hamma narsani (`.github` papkasi bilan birga) repo ildiziga yuklang.
3. Repo > Actions > "Build APK" ishga tushadi (yoki Run workflow).
4. Tugagach, run sahifasi pastidagi Artifacts > Zakazlar-APK ni yuklab oling, ichidan app-debug.apk ni o'rnating.
