package uz.shoxrux.zakazlar

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import uz.shoxrux.zakazlar.notify.Reminders
import uz.shoxrux.zakazlar.ui.AppRoot
import uz.shoxrux.zakazlar.ui.ZakazTheme

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT))
        Reminders.ensureChannel(this)
        setContent {
            ZakazTheme {
                AppRoot(vm)
            }
        }
    }
}
