package uz.shoxrux.zakazlar.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

@Immutable
class Extra(
    val success: Color,
    val successSoft: Color,
    val danger: Color,
    val dangerSoft: Color,
    val gold: Color,
    val onGold: Color,
    val headerStart: Color,
    val headerEnd: Color,
)

private val LightExtra = Extra(
    success = Color(0xFF1E9E6A),
    successSoft = Color(0xFFE3F4EC),
    danger = Color(0xFFD64545),
    dangerSoft = Color(0xFFFCEDED),
    gold = Color(0xFFD9B45F),
    onGold = Color(0xFF241A05),
    headerStart = Color(0xFF15223D),
    headerEnd = Color(0xFF2D4272),
)

private val DarkExtra = Extra(
    success = Color(0xFF3CCB8E),
    successSoft = Color(0xFF16322A),
    danger = Color(0xFFFF6B6B),
    dangerSoft = Color(0xFF3A1D24),
    gold = Color(0xFFE3C37A),
    onGold = Color(0xFF241A05),
    headerStart = Color(0xFF1D2D52),
    headerEnd = Color(0xFF0E1420),
)

val LocalExtra = staticCompositionLocalOf { LightExtra }

val extra: Extra
    @Composable get() = LocalExtra.current

private val LightColors = lightColorScheme(
    primary = Color(0xFF1B2A49),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE6E9F2),
    onPrimaryContainer = Color(0xFF1B2A49),
    secondary = Color(0xFFB8903A),
    onSecondary = Color.White,
    background = Color(0xFFF5F3EE),
    onBackground = Color(0xFF1A1D24),
    surface = Color.White,
    onSurface = Color(0xFF1A1D24),
    surfaceVariant = Color(0xFFECE8DF),
    onSurfaceVariant = Color(0xFF6B7080),
    outline = Color(0xFFD5D0C3),
    outlineVariant = Color(0xFFE8E3D8),
    error = Color(0xFFD64545),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFE3C37A),
    onPrimary = Color(0xFF241A05),
    primaryContainer = Color(0xFF2B3550),
    onPrimaryContainer = Color(0xFFE3C37A),
    secondary = Color(0xFFE3C37A),
    onSecondary = Color(0xFF241A05),
    background = Color(0xFF0E1420),
    onBackground = Color(0xFFEDEFF4),
    surface = Color(0xFF161E2E),
    onSurface = Color(0xFFEDEFF4),
    surfaceVariant = Color(0xFF1F2940),
    onSurfaceVariant = Color(0xFF9AA3B5),
    outline = Color(0xFF34405C),
    outlineVariant = Color(0xFF263149),
    error = Color(0xFFFF6B6B),
)

@Composable
fun ZakazTheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalExtra provides (if (dark) DarkExtra else LightExtra)) {
        MaterialTheme(
            colorScheme = if (dark) DarkColors else LightColors,
            content = content
        )
    }
}
