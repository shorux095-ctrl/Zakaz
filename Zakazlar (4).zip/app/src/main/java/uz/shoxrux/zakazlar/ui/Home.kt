package uz.shoxrux.zakazlar.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.EventAvailable
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import uz.shoxrux.zakazlar.data.Order
import uz.shoxrux.zakazlar.util.Dates
import uz.shoxrux.zakazlar.util.NameMatch
import uz.shoxrux.zakazlar.util.Money
import androidx.compose.material.icons.rounded.AttachMoney
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.rememberSwipeToDismissBoxState

@Composable
fun HomeScreen(
    orders: List<Order>,
    onAdd: (Long) -> Unit,
    onOpen: (Order) -> Unit,
    onToggle: (Order) -> Unit,
    onOpenCustomer: (String) -> Unit,
    onDelete: (Order) -> Unit,
    onTogglePaid: (Order) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val ex = extra
    val today = Dates.today()

    var range by rememberSaveable { mutableStateOf("TODAY") }
    var pickedDay by rememberSaveable { mutableStateOf(today + 1) }
    var status by rememberSaveable { mutableStateOf(0) }
    var searching by rememberSaveable { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }
    var showPicker by remember { mutableStateOf(false) }

    BackHandler(enabled = searching) {
        searching = false
        query = ""
    }

    fun pick(r: String) {
        range = r
        searching = false
        query = ""
    }

    val pendingToday = orders.count { it.dateEpochDay == today && !it.done }
    val pendingTomorrow = orders.count { it.dateEpochDay == today + 1 && !it.done }
    val overdue = orders.count { it.dateEpochDay < today && !it.done }
    val payPending = orders.count { it.payDay != null && !it.paid }
    val payOverdue = orders.count { val p = it.payDay; p != null && !it.paid && p < today }
    val payTotal = orders.filter { it.payDay != null && !it.paid }.sumOf { it.amount ?: 0L }

    val searchActive = searching && query.isNotBlank()
    val nq = NameMatch.norm(query)

    val base: List<Order> = if (searchActive) {
        orders.filter {
            NameMatch.score(query, it.customer) != null || NameMatch.norm(it.details).contains(nq)
        }
    } else when (range) {
        "OVERDUE" -> orders.filter { it.dateEpochDay < today && !it.done }
        "TODAY" -> orders.filter { it.dateEpochDay == today }
        "TOMORROW" -> orders.filter { it.dateEpochDay == today + 1 }
        "PLUS3" -> orders.filter { it.dateEpochDay == today + 3 }
        "PICKED" -> orders.filter { it.dateEpochDay == pickedDay }
        "HISTORY" -> orders.filter { it.dateEpochDay < today }
        "PAY" -> orders.filter { it.payDay != null && !it.paid }
        else -> orders
    }
    val shown: List<Order> = when (status) {
        1 -> base.filter { !it.done }
        2 -> base.filter { it.done }
        else -> base
    }
    val cAll = base.size
    val cPending = base.count { !it.done }
    val cDone = cAll - cPending

    val dayOrder: Comparator<Long> =
        if (range == "HISTORY" && !searchActive) {
            reverseOrder<Long>()
        } else if (range == "ALL" || searchActive) {
            compareBy<Long> { d -> if (d >= today) d - today else 1_000_000L + (today - d) }
        } else {
            naturalOrder<Long>()
        }
    val groups = shown
        .groupBy { if (range == "PAY" && !searchActive) (it.payDay ?: it.dateEpochDay) else it.dateEpochDay }
        .toSortedMap(dayOrder)

    val defaultDay = when (range) {
        "TODAY" -> today
        "PLUS3" -> today + 3
        "PICKED" -> pickedDay
        else -> today + 1
    }

    if (showPicker) {
        DayPickerDialog(
            initialDay = pickedDay,
            onPick = {
                pickedDay = it
                pick("PICKED")
            },
            onDismiss = { showPicker = false }
        )
    }

    Scaffold(
        containerColor = cs.background,
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { onAdd(defaultDay) },
                containerColor = ex.gold,
                contentColor = ex.onGold,
                shape = RoundedCornerShape(20.dp)
            ) {
                Icon(Icons.Rounded.Add, null)
                Spacer(Modifier.width(8.dp))
                Text("Yangi zakaz", fontWeight = FontWeight.Bold)
            }
        }
    ) { inner ->
        Column(Modifier.fillMaxSize()) {
            HomeHeader(
                today = today,
                pendingToday = pendingToday,
                pendingTomorrow = pendingTomorrow,
                overdue = overdue,
                searching = searching,
                query = query,
                onQuery = { query = it },
                onToggleSearch = {
                    searching = !searching
                    if (!searching) query = ""
                },
                onTile = { pick(it) }
            )
            Spacer(Modifier.height(14.dp))

            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (overdue > 0 || range == "OVERDUE") {
                    item {
                        Pill(
                            "O'tgan ($overdue)",
                            !searchActive && range == "OVERDUE",
                            { pick("OVERDUE") },
                            danger = true
                        )
                    }
                }
                item { Pill("Bugun", !searchActive && range == "TODAY", { pick("TODAY") }) }
                item { Pill("Ertaga", !searchActive && range == "TOMORROW", { pick("TOMORROW") }) }
                item { Pill("3 kundan keyin", !searchActive && range == "PLUS3", { pick("PLUS3") }) }
                item {
                    Pill(
                        if (range == "PICKED") Dates.short(pickedDay) else "Sana tanlash",
                        !searchActive && range == "PICKED",
                        { showPicker = true },
                        icon = Icons.Rounded.CalendarMonth
                    )
                }
                item {
                    Pill(
                        "Pul ($payPending)",
                        !searchActive && range == "PAY",
                        { pick("PAY") },
                        icon = Icons.Rounded.AttachMoney,
                        danger = payOverdue > 0
                    )
                }
                item {
                    Pill(
                        "Tarix",
                        !searchActive && range == "HISTORY",
                        { pick("HISTORY") },
                        icon = Icons.Rounded.History
                    )
                }
                item { Pill("Hammasi", !searchActive && range == "ALL", { pick("ALL") }) }
            }
            Spacer(Modifier.height(10.dp))

            Row(
                Modifier
                    .padding(horizontal = 16.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(cs.surfaceVariant)
                    .padding(4.dp)
            ) {
                val labels = listOf("Hammasi $cAll", "Berilmagan $cPending", "Berilgan $cDone")
                labels.forEachIndexed { i, t ->
                    val sel = status == i
                    Box(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(11.dp))
                            .background(if (sel) cs.surface else Color.Transparent)
                            .clickable { status = i }
                            .padding(vertical = 9.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            t,
                            fontSize = 13.sp,
                            maxLines = 1,
                            fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Medium,
                            color = if (sel) cs.onSurface else cs.onSurfaceVariant
                        )
                    }
                }
            }
            Spacer(Modifier.height(6.dp))

            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(
                    start = 16.dp, end = 16.dp, top = 4.dp,
                    bottom = inner.calculateBottomPadding() + 96.dp
                ),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (range == "PAY" && !searchActive && payTotal > 0) {
                    item(key = "paytotal") { PayTotalCard(payTotal) }
                }
                if (groups.isEmpty()) {
                    item(key = "empty") {
                        val title = when {
                            base.isNotEmpty() && shown.isEmpty() -> "Bu bo'limda zakaz yo'q"
                            searchActive -> "Hech narsa topilmadi"
                            range == "OVERDUE" -> "Muddati o'tgan zakaz yo'q"
                            range == "TODAY" -> "Bugunga zakaz yo'q"
                            range == "TOMORROW" -> "Ertaga zakaz yo'q"
                            range == "PAY" -> "Kutilayotgan pul yo'q"
                            range == "HISTORY" -> "Tarixda zakaz yo'q"
                            range == "ALL" -> "Hozircha zakaz yo'q"
                            else -> "Bu kunga zakaz yo'q"
                        }
                        val sub = if (searchActive) "Boshqa so'z bilan qidirib ko'ring"
                        else "Pastdagi tugma bilan yangi zakaz qo'shing"
                        EmptyState(title, sub)
                    }
                }
                for ((day, list) in groups) {
                    item(key = "h$day") {
                        if (range == "PAY" && !searchActive) PayHeader(day, today, list)
                        else DayHeader(day, today, list)
                    }
                    items(list.sortedBy { it.done }, key = { it.id }) { o ->
                        SwipeCard(
                            o = o,
                            today = today,
                            onClick = { onOpen(o) },
                            onToggle = { onToggle(o) },
                            onOpenCustomer = { onOpenCustomer(o.customer) },
                            onTogglePaid = { onTogglePaid(o) },
                            onDelete = { onDelete(o) },
                            modifier = Modifier.animateItem()
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeHeader(
    today: Long,
    pendingToday: Int,
    pendingTomorrow: Int,
    overdue: Int,
    searching: Boolean,
    query: String,
    onQuery: (String) -> Unit,
    onToggleSearch: () -> Unit,
    onTile: (String) -> Unit,
) {
    val ex = extra
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
            .background(headerBrush())
            .statusBarsPadding()
            .padding(start = 20.dp, end = 12.dp, top = 12.dp, bottom = 20.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    "ZAKAZLAR",
                    color = ex.gold,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                )
                Text(
                    Dates.full(today),
                    color = Color.White,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            IconButton(onClick = onToggleSearch) {
                Icon(
                    if (searching) Icons.Rounded.Close else Icons.Rounded.Search,
                    contentDescription = null,
                    tint = Color.White
                )
            }
        }
        AnimatedVisibility(visible = searching) {
            SearchField(query, onQuery)
        }
        Spacer(Modifier.height(16.dp))
        Row(
            Modifier.padding(end = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            StatTile("Bugun", pendingToday, false, { onTile("TODAY") }, Modifier.weight(1f))
            StatTile("Ertaga", pendingTomorrow, false, { onTile("TOMORROW") }, Modifier.weight(1f))
            StatTile("O'tgan", overdue, true, { onTile("OVERDUE") }, Modifier.weight(1f))
        }
    }
}

@Composable
private fun SearchField(query: String, onQuery: (String) -> Unit) {
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { focus.requestFocus() }
    val white = Color.White
    val container = Color.White.copy(alpha = 0.12f)
    TextField(
        value = query,
        onValueChange = onQuery,
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 10.dp, end = 8.dp)
            .focusRequester(focus),
        singleLine = true,
        placeholder = { Text("Mijoz yoki zakaz bo'yicha qidirish") },
        leadingIcon = { Icon(Icons.Rounded.Search, null) },
        shape = RoundedCornerShape(16.dp),
        colors = TextFieldDefaults.colors(
            focusedContainerColor = container,
            unfocusedContainerColor = container,
            focusedIndicatorColor = Color.Transparent,
            unfocusedIndicatorColor = Color.Transparent,
            focusedTextColor = white,
            unfocusedTextColor = white,
            cursorColor = extra.gold,
            focusedPlaceholderColor = white.copy(alpha = 0.6f),
            unfocusedPlaceholderColor = white.copy(alpha = 0.6f),
            focusedLeadingIconColor = white.copy(alpha = 0.8f),
            unfocusedLeadingIconColor = white.copy(alpha = 0.8f),
        )
    )
}

@Composable
fun StatTile(
    label: String,
    value: Int,
    danger: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val hot = danger && value > 0
    Surface(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        color = if (hot) extra.danger.copy(alpha = 0.25f) else Color.White.copy(alpha = 0.10f)
    ) {
        Column(Modifier.padding(horizontal = 14.dp, vertical = 12.dp)) {
            Text(
                value.toString(),
                color = if (hot) Color(0xFFFFA3A3) else Color.White,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold
            )
            Text(label, color = Color.White.copy(alpha = 0.72f), fontSize = 12.sp, maxLines = 1)
        }
    }
}

@Composable
fun DayHeader(day: Long, today: Long, list: List<Order>) {
    val cs = MaterialTheme.colorScheme
    val late = day < today && list.any { !it.done }
    Row(
        Modifier
            .fillMaxWidth()
            .padding(top = 10.dp, start = 4.dp, end = 4.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        Text(
            Dates.label(day, today),
            modifier = Modifier.weight(1f),
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = cs.onSurface
        )
        if (late) {
            Text(
                "${today - day} kun o'tgan",
                color = extra.danger,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
        } else {
            Text(
                "${list.count { it.done }}/${list.size} berilgan",
                color = cs.onSurfaceVariant,
                fontSize = 12.sp
            )
        }
    }
}

@Composable
fun SwipeCard(
    o: Order,
    today: Long,
    onClick: () -> Unit,
    onToggle: () -> Unit,
    onOpenCustomer: () -> Unit,
    onTogglePaid: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val ex = extra
    val state = rememberSwipeToDismissBoxState(
        confirmValueChange = { v ->
            if (v == SwipeToDismissBoxValue.EndToStart) {
                onDelete()
                true
            } else {
                false
            }
        }
    )
    SwipeToDismissBox(
        state = state,
        modifier = modifier,
        enableDismissFromStartToEnd = false,
        backgroundContent = {
            val active = state.dismissDirection == SwipeToDismissBoxValue.EndToStart
            Box(
                Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(20.dp))
                    .background(if (active) ex.danger else Color.Transparent)
                    .padding(end = 24.dp),
                contentAlignment = Alignment.CenterEnd
            ) {
                if (active) Icon(Icons.Rounded.Delete, null, tint = Color.White)
            }
        }
    ) {
        OrderCard(
            o = o,
            today = today,
            onClick = onClick,
            onToggle = onToggle,
            onOpenCustomer = onOpenCustomer,
            onTogglePaid = onTogglePaid
        )
    }
}

@Composable
fun OrderCard(
    o: Order,
    today: Long,
    onClick: () -> Unit,
    onToggle: () -> Unit,
    onOpenCustomer: () -> Unit = {},
    onTogglePaid: () -> Unit = {},
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val ex = extra
    val late = !o.done && o.dateEpochDay < today
    Surface(
        onClick = onClick,
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = if (late) ex.dangerSoft else cs.surface,
        border = BorderStroke(
            1.dp,
            if (late) ex.danger.copy(alpha = 0.35f) else cs.outlineVariant
        ),
        shadowElevation = 1.dp
    ) {
        Row(
            Modifier
                .alpha(if (o.done) 0.72f else 1f)
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CheckCircle(o.done, onToggle)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(
                    o.customer,
                    modifier = Modifier.clickable(onClick = onOpenCustomer),
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (o.done) cs.onSurfaceVariant else cs.onSurface,
                    textDecoration = if (o.done) TextDecoration.LineThrough else null,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (o.details.isNotBlank()) {
                    Text(
                        o.details,
                        fontSize = 14.sp,
                        color = cs.onSurfaceVariant,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                val t = o.timeMinutes
                if (t != null || late || (o.reminderMode > 0 && !o.done)) {
                    Row(
                        Modifier.padding(top = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (t != null) MiniChip(Icons.Rounded.Schedule, Dates.clock(t), false)
                        if (late) MiniChip(null, "${today - o.dateEpochDay} kun o'tgan", true)
                        if (o.reminderMode > 0 && !o.done) {
                            Icon(
                                Icons.Rounded.NotificationsActive,
                                contentDescription = null,
                                tint = cs.onSurfaceVariant,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
                val pd = o.payDay
                val amt = o.amount
                if (pd != null || amt != null) {
                    val payLate = pd != null && !o.paid && pd < today
                    val sum = if (amt != null) " · " + Money.fmt(amt) else ""
                    val txt = if (pd == null) {
                        Money.fmt(amt ?: 0L) + " so'm"
                    } else when {
                        o.paid -> "To'langan$sum"
                        pd < today -> "Pul ${today - pd} kun o'tgan$sum"
                        else -> "Pul: ${Dates.short(pd)}$sum"
                    }
                    Row(Modifier.padding(top = 2.dp)) {
                        MiniChip(
                            Icons.Rounded.AttachMoney,
                            txt,
                            danger = payLate,
                            success = pd != null && o.paid,
                            onClick = if (pd != null) onTogglePaid else null
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MiniChip(
    icon: ImageVector?,
    text: String,
    danger: Boolean,
    success: Boolean = false,
    onClick: (() -> Unit)? = null,
) {
    val cs = MaterialTheme.colorScheme
    val ex = extra
    val fg = when {
        danger -> ex.danger
        success -> ex.success
        else -> cs.onSurfaceVariant
    }
    val bgc = when {
        danger -> ex.danger.copy(alpha = 0.12f)
        success -> ex.success.copy(alpha = 0.14f)
        else -> cs.surfaceVariant
    }
    Row(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(bgc)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 9.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        if (icon != null) Icon(icon, null, Modifier.size(14.dp), tint = fg)
        Text(text, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = fg)
    }
}

@Composable
fun PayHeader(day: Long, today: Long, list: List<Order>) {
    val cs = MaterialTheme.colorScheme
    val sum = list.sumOf { it.amount ?: 0L }
    val sumText = if (sum > 0) Money.fmt(sum) + " so'm" else "${list.size} ta"
    Row(
        Modifier
            .fillMaxWidth()
            .padding(top = 10.dp, start = 4.dp, end = 4.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        Text(
            Dates.label(day, today),
            modifier = Modifier.weight(1f),
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = cs.onSurface
        )
        if (day < today) {
            Text(
                "${today - day} kun o'tgan · $sumText",
                color = extra.danger,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
        } else {
            Text(sumText, color = cs.onSurfaceVariant, fontSize = 12.sp)
        }
    }
}

@Composable
fun PayTotalCard(total: Long) {
    val cs = MaterialTheme.colorScheme
    val ex = extra
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = ex.successSoft,
        border = BorderStroke(1.dp, ex.success.copy(alpha = 0.3f))
    ) {
        Row(
            Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(ex.success),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.AttachMoney, null, tint = Color.White)
            }
            Spacer(Modifier.width(14.dp))
            Column {
                Text("Kutilayotgan pul", fontSize = 13.sp, color = cs.onSurfaceVariant)
                Text(
                    Money.fmt(total) + " so'm",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = cs.onSurface
                )
            }
        }
    }
}

@Composable
private fun CheckCircle(done: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val ex = extra
    val haptic = LocalHapticFeedback.current
    val bg by animateColorAsState(if (done) ex.success else Color.Transparent, label = "chk")
    val ring = if (done) ex.success else cs.outline
    Box(
        Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(bg)
            .border(2.dp, ring, CircleShape)
            .clickable {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                onClick()
            },
        contentAlignment = Alignment.Center
    ) {
        if (done) {
            Icon(Icons.Rounded.Check, null, Modifier.size(26.dp), tint = Color.White)
        }
    }
}

@Composable
fun EmptyState(title: String, sub: String) {
    val cs = MaterialTheme.colorScheme
    Column(
        Modifier
            .fillMaxWidth()
            .padding(top = 56.dp, start = 24.dp, end = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .size(88.dp)
                .clip(CircleShape)
                .background(cs.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Rounded.EventAvailable, null,
                Modifier.size(40.dp), tint = cs.onSurfaceVariant
            )
        }
        Spacer(Modifier.height(16.dp))
        Text(title, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurface)
        Spacer(Modifier.height(4.dp))
        Text(sub, fontSize = 14.sp, color = cs.onSurfaceVariant, textAlign = TextAlign.Center)
    }
}
