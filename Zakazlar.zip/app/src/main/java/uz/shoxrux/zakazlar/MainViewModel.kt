package uz.shoxrux.zakazlar

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import uz.shoxrux.zakazlar.data.AppDatabase
import uz.shoxrux.zakazlar.data.Order
import uz.shoxrux.zakazlar.notify.Reminders
import uz.shoxrux.zakazlar.widget.TodayWidget

class MainViewModel(private val app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).orderDao()

    val orders: StateFlow<List<Order>> =
        dao.observeAll().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun save(order: Order) {
        viewModelScope.launch {
            val id = dao.upsert(order)
            val saved = if (order.id == 0L) order.copy(id = id) else order
            Reminders.schedule(app, saved)
            TodayWidget.refresh(app)
        }
    }

    fun toggleDone(o: Order) {
        viewModelScope.launch {
            val n = o.copy(done = !o.done, doneAt = if (!o.done) System.currentTimeMillis() else null)
            dao.upsert(n)
            Reminders.schedule(app, n)
            TodayWidget.refresh(app)
        }
    }

    fun togglePaid(o: Order) {
        viewModelScope.launch {
            val n = o.copy(paid = !o.paid)
            dao.upsert(n)
            Reminders.schedule(app, n)
            TodayWidget.refresh(app)
        }
    }

    fun markSent(ids: List<Long>) {
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            ids.forEach { id ->
                dao.get(id)?.let { dao.upsert(it.copy(sentAt = now)) }
            }
        }
    }

    fun delete(o: Order) {
        viewModelScope.launch {
            dao.delete(o)
            Reminders.cancel(app, o.id)
            TodayWidget.refresh(app)
        }
    }
}
