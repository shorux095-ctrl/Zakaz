package uz.shoxrux.zakazlar.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.widget.RemoteViews
import android.widget.RemoteViewsService
import kotlinx.coroutines.runBlocking
import uz.shoxrux.zakazlar.MainActivity
import uz.shoxrux.zakazlar.R
import uz.shoxrux.zakazlar.data.AppDatabase
import uz.shoxrux.zakazlar.data.Order
import uz.shoxrux.zakazlar.util.Dates

class TodayWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) update(context, appWidgetManager, id)
    }

    companion object {
        fun update(ctx: Context, mgr: AppWidgetManager, id: Int) {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_today)
            val svc = Intent(ctx, WidgetService::class.java)
            svc.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            svc.data = Uri.parse(svc.toUri(Intent.URI_INTENT_SCHEME))
            rv.setRemoteAdapter(R.id.widget_list, svc)
            rv.setEmptyView(R.id.widget_list, R.id.widget_empty)
            rv.setTextViewText(R.id.widget_title, "Bugun · " + Dates.short(Dates.today()))
            val open = PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            rv.setOnClickPendingIntent(R.id.widget_title, open)
            rv.setOnClickPendingIntent(R.id.widget_empty, open)
            rv.setPendingIntentTemplate(R.id.widget_list, open)
            mgr.updateAppWidget(id, rv)
        }

        fun refresh(ctx: Context) {
            try {
                val mgr = AppWidgetManager.getInstance(ctx)
                val ids = mgr.getAppWidgetIds(ComponentName(ctx, TodayWidget::class.java))
                if (ids.isEmpty()) return
                for (id in ids) update(ctx, mgr, id)
                mgr.notifyAppWidgetViewDataChanged(ids, R.id.widget_list)
            } catch (e: Exception) {
                // vidjet yangilanmasa ilova ishiga xalaqit bermasin
            }
        }
    }
}

class WidgetService : RemoteViewsService() {
    override fun onGetViewFactory(intent: Intent): RemoteViewsFactory =
        WidgetFactory(applicationContext)
}

private class WidgetFactory(private val ctx: Context) : RemoteViewsService.RemoteViewsFactory {
    private var items: List<Order> = emptyList()

    override fun onCreate() {}

    override fun onDataSetChanged() {
        items = runBlocking { AppDatabase.get(ctx).orderDao().widgetList(Dates.today()) }
    }

    override fun onDestroy() {}

    override fun getCount(): Int = items.size

    override fun getViewAt(position: Int): RemoteViews {
        val rv = RemoteViews(ctx.packageName, R.layout.widget_item)
        val o = items.getOrNull(position) ?: return rv
        val today = Dates.today()
        val late = o.dateEpochDay < today
        val time = o.timeMinutes?.let { Dates.clock(it) + "  " } ?: ""
        rv.setTextViewText(R.id.w_name, time + o.customer)
        rv.setTextColor(R.id.w_name, if (late) Color.parseColor("#FF8A8A") else Color.WHITE)
        val sub = buildString {
            if (late) append((today - o.dateEpochDay).toString() + " kun o'tgan")
            if (o.details.isNotBlank()) {
                if (isNotEmpty()) append(" · ")
                append(o.details)
            }
        }
        rv.setTextViewText(R.id.w_sub, sub)
        rv.setOnClickFillInIntent(R.id.w_root, Intent())
        return rv
    }

    override fun getLoadingView(): RemoteViews? = null

    override fun getViewTypeCount(): Int = 1

    override fun getItemId(position: Int): Long = items.getOrNull(position)?.id ?: position.toLong()

    override fun hasStableIds(): Boolean = true
}
