package uz.shoxrux.zakazlar.notify

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import uz.shoxrux.zakazlar.MainActivity
import uz.shoxrux.zakazlar.R
import uz.shoxrux.zakazlar.data.AppDatabase
import uz.shoxrux.zakazlar.data.Order
import uz.shoxrux.zakazlar.util.Dates
import uz.shoxrux.zakazlar.util.Money
import java.time.LocalDate
import java.time.ZoneId

object Reminders {
    const val CHANNEL = "zakaz_eslatma"
    private const val PAY_OFFSET = 1_000_000_000L

    fun ensureChannel(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null) {
            val ch = NotificationChannel(CHANNEL, "Zakaz eslatmalari", NotificationManager.IMPORTANCE_HIGH)
            ch.description = "Zakaz va pul berish muddati haqida eslatma"
            nm.createNotificationChannel(ch)
        }
    }

    fun triggerAt(o: Order): Long? {
        if (o.reminderMode == 0) return null
        val date = LocalDate.ofEpochDay(o.dateEpochDay)
        val t = o.timeMinutes
        val morning = date.atTime(8, 0)
        val dt = when {
            t == null -> morning
            o.reminderMode == 2 -> date.atTime(t / 60, t % 60)
            o.reminderMode == 3 -> date.atTime(t / 60, t % 60).minusHours(1)
            else -> morning
        }
        return dt.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
    }

    fun payTriggerAt(o: Order): Long? {
        val p = o.payDay ?: return null
        if (o.paid) return null
        return LocalDate.ofEpochDay(p).atTime(8, 0)
            .atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
    }

    private fun alarmIntent(ctx: Context, id: Long, kind: Int): PendingIntent {
        val i = Intent(ctx, ReminderReceiver::class.java)
            .putExtra("id", id)
            .putExtra("kind", kind)
        val code = if (kind == 1) (id + PAY_OFFSET).toInt() else id.toInt()
        return PendingIntent.getBroadcast(
            ctx, code, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun cancel(ctx: Context, id: Long) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        am.cancel(alarmIntent(ctx, id, 0))
        am.cancel(alarmIntent(ctx, id, 1))
    }

    fun schedule(ctx: Context, o: Order) {
        cancel(ctx, o.id)
        val am = ctx.getSystemService(AlarmManager::class.java)
        val now = System.currentTimeMillis()
        if (!o.done && !o.later) {
            val at = triggerAt(o)
            if (at != null && at > now) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, alarmIntent(ctx, o.id, 0))
            }
        }
        val pay = payTriggerAt(o)
        if (pay != null && pay > now) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, pay, alarmIntent(ctx, o.id, 1))
        }
    }

    private fun canNotify(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED

    private fun openApp(ctx: Context, code: Int): PendingIntent =
        PendingIntent.getActivity(
            ctx, code,
            Intent(ctx, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    @SuppressLint("MissingPermission")
    fun show(ctx: Context, o: Order) {
        if (!canNotify(ctx)) return
        ensureChannel(ctx)
        val time = o.timeMinutes?.let { Dates.clock(it) + " · " } ?: ""
        val body = time + o.details.ifBlank { "Zakazni berish vaqti keldi" }
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(o.customer)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(openApp(ctx, o.id.toInt()))
            .build()
        NotificationManagerCompat.from(ctx).notify(o.id.toInt(), n)
    }

    @SuppressLint("MissingPermission")
    fun showPay(ctx: Context, o: Order) {
        if (!canNotify(ctx)) return
        ensureChannel(ctx)
        val sum = o.amount?.let { " · " + Money.fmt(it) + " so'm" } ?: ""
        val body = "Bugun pul berish kuni$sum"
        val code = (o.id + PAY_OFFSET).toInt()
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Pul: " + o.customer)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(openApp(ctx, code))
            .build()
        NotificationManagerCompat.from(ctx).notify(code, n)
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra("id", -1L)
        val kind = intent.getIntExtra("kind", 0)
        if (id < 0) return
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val o = AppDatabase.get(context).orderDao().get(id)
                if (o != null) {
                    if (kind == 1) {
                        if (o.payDay != null && !o.paid) Reminders.showPay(context, o)
                    } else if (!o.done) {
                        Reminders.show(context, o)
                    }
                }
            } finally {
                pending.finish()
            }
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val list = AppDatabase.get(context).orderDao().pendingFrom(Dates.today())
                list.forEach { Reminders.schedule(context, it) }
            } finally {
                pending.finish()
            }
        }
    }
}
